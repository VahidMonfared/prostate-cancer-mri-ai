
# =====================================================================
# AGENT B — BEST INTERNAL OOF PERFORMANCE + INTERNAL GRAD-CAM
# Focus: highest internal Track-B replay (OOF ROC-AUC ~0.882)
#
# Required in /content:
#   - PI_CAI_Bv3_Hidden_Test_Submission_Source.zip
#   - cancer.zip  (or any *cancer*.zip)
#   - normal.zip  (or any *normal*.zip)
#
# This script:
#   1) reconstructs the exact approved 243-image internal cohort,
#   2) reproduces the original 5-fold OOF Track-B predictions,
#   3) applies the locked Platt calibration + Youden threshold,
#   4) reports ROC-AUC, PR-AUC/AP, Accuracy, Sensitivity, Specificity,
#      PPV, NPV, F1, Brier, confusion matrix, and bootstrap AUC CI,
#   5) draws ROC, PR, confusion matrix, calibration plot, fold-AUC plot,
#   6) generates fold-specific INTERNAL Grad-CAM exemplars using the
#      exact validation-fold model for each selected OOF case,
#   7) exports a paper-ready ZIP.
#
# No retraining. No external labels. No test-label threshold optimization.
# =====================================================================

import os, io, re, gc, json, math, shutil, zipfile, hashlib, subprocess, sys, warnings
from pathlib import Path

subprocess.run(
    [sys.executable, "-m", "pip", "install", "-q",
     "timm", "opencv-python-headless", "scikit-learn"],
    check=True
)

import numpy as np
import pandas as pd
import cv2
from PIL import Image, ImageFile
ImageFile.LOAD_TRUNCATED_IMAGES = True

import torch
import torch.nn as nn
from torchvision import transforms
import timm

from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import (
    roc_auc_score, average_precision_score, accuracy_score,
    precision_score, recall_score, f1_score, confusion_matrix,
    brier_score_loss, roc_curve, precision_recall_curve
)
from sklearn.calibration import calibration_curve
import matplotlib.pyplot as plt

warnings.filterwarnings("ignore")

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("DEVICE:", DEVICE)
if DEVICE == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))

# ---------------------------------------------------------------------
# 0) locate required files
# ---------------------------------------------------------------------
CONTENT = Path("/content")

PI_ZIP = CONTENT / "PI_CAI_Bv3_Hidden_Test_Submission_Source.zip"
if not PI_ZIP.exists():
    raise FileNotFoundError(
        "Upload PI_CAI_Bv3_Hidden_Test_Submission_Source.zip to /content"
    )

def find_zip(keyword):
    cands = [
        p for p in CONTENT.glob("*.zip")
        if keyword.lower() in p.name.lower()
        and "result" not in p.name.lower()
        and "source" not in p.name.lower()
    ]
    if not cands:
        raise FileNotFoundError(
            f"Upload the institutional {keyword}.zip to /content"
        )
    return sorted(cands, key=lambda p: p.stat().st_size, reverse=True)[0]

CANCER_ZIP = find_zip("cancer")
NORMAL_ZIP = find_zip("normal")

ROOT = CONTENT / "AgentB_Best_Internal_OOF"
RAW = ROOT / "raw"
BUNDLE = ROOT / "bundle"
OUT = ROOT / "results"
FIG = OUT / "figures"

if ROOT.exists():
    shutil.rmtree(ROOT)
for p in [RAW/"cancer", RAW/"normal", BUNDLE, OUT, FIG]:
    p.mkdir(parents=True, exist_ok=True)

print("Cancer ZIP:", CANCER_ZIP.name)
print("Normal ZIP:", NORMAL_ZIP.name)

# ---------------------------------------------------------------------
# 1) extract sources
# ---------------------------------------------------------------------
with zipfile.ZipFile(PI_ZIP) as z:
    z.extractall(BUNDLE)

BROOT = BUNDLE / "bv3_bundle"
MODELS = BROOT / "models"
ART = BROOT / "artifacts"

with zipfile.ZipFile(CANCER_ZIP) as z:
    z.extractall(RAW/"cancer")
with zipfile.ZipFile(NORMAL_ZIP) as z:
    z.extractall(RAW/"normal")

# ---------------------------------------------------------------------
# 2) reconstruct exact clean cohort
# ---------------------------------------------------------------------
VALID_EXTS = {".jpg",".jpeg",".png",".bmp",".tif",".tiff"}

def collect_images(folder):
    return sorted([
        p for p in folder.rglob("*")
        if p.is_file() and p.suffix.lower() in VALID_EXTS
    ])

def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1024*1024), b""):
            h.update(b)
    return h.hexdigest()

def color_overlay_fraction(path):
    rgb = np.asarray(Image.open(path).convert("RGB"), dtype=np.int16)
    d = np.maximum.reduce([
        np.abs(rgb[...,0]-rgb[...,1]),
        np.abs(rgb[...,0]-rgb[...,2]),
        np.abs(rgb[...,1]-rgb[...,2]),
    ])
    return float((d > 12).mean())

rows = []
for cls, label in [("cancer",1),("normal",0)]:
    for p in collect_images(RAW/cls):
        rows.append({
            "path": str(p),
            "class": cls,
            "label": label,
            "sha256": sha256_file(p),
            "color_overlay_fraction": color_overlay_fraction(p),
        })

df = pd.DataFrame(rows)

conf = df.groupby("sha256")["label"].nunique()
if (conf > 1).any():
    raise RuntimeError("Conflicting-label exact duplicates found.")

df = df.drop_duplicates("sha256", keep="first").reset_index(drop=True)
df = df[df["color_overlay_fraction"] <= 0.001].reset_index(drop=True)

print("Clean internal cohort:", len(df))
print(df["class"].value_counts().to_dict())

if len(df) != 243:
    raise RuntimeError(
        f"Expected exact approved internal n=243; reconstructed n={len(df)}. "
        "Use the original Cancer/Normal source ZIPs."
    )

# ---------------------------------------------------------------------
# 3) exact Stage2R preprocessing
# ---------------------------------------------------------------------
IMG_SIZE = 224
SEG_SIZE = 256
ROI_MARGIN = 0.18
MIN_MASK_FRAC = 0.015
MAX_MASK_FRAC = 0.60

class DoubleConv(nn.Module):
    def __init__(self,a,b):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(a,b,3,padding=1), nn.BatchNorm2d(b), nn.ReLU(inplace=True),
            nn.Conv2d(b,b,3,padding=1), nn.BatchNorm2d(b), nn.ReLU(inplace=True)
        )
    def forward(self,x): return self.net(x)

class SmallUNet(nn.Module):
    def __init__(self,base=32):
        super().__init__()
        self.c1=DoubleConv(1,base); self.p1=nn.MaxPool2d(2)
        self.c2=DoubleConv(base,base*2); self.p2=nn.MaxPool2d(2)
        self.c3=DoubleConv(base*2,base*4); self.p3=nn.MaxPool2d(2)
        self.c4=DoubleConv(base*4,base*8)
        self.u3=nn.ConvTranspose2d(base*8,base*4,2,2); self.d3=DoubleConv(base*8,base*4)
        self.u2=nn.ConvTranspose2d(base*4,base*2,2,2); self.d2=DoubleConv(base*4,base*2)
        self.u1=nn.ConvTranspose2d(base*2,base,2,2); self.d1=DoubleConv(base*2,base)
        self.out=nn.Conv2d(base,1,1)
    def forward(self,x):
        c1=self.c1(x); c2=self.c2(self.p1(c1)); c3=self.c3(self.p2(c2)); c4=self.c4(self.p3(c3))
        x=self.u3(c4); x=self.d3(torch.cat([x,c3],1))
        x=self.u2(x); x=self.d2(torch.cat([x,c2],1))
        x=self.u1(x); x=self.d1(torch.cat([x,c1],1))
        return self.out(x)

class ResizePad:
    def __init__(self,size,fill=0):
        self.size=size; self.fill=fill
    def __call__(self,img):
        w,h=img.size
        scale=self.size/max(w,h)
        nw,nh=max(1,round(w*scale)),max(1,round(h*scale))
        img=img.resize((nw,nh),Image.BILINEAR)
        canvas=Image.new("RGB",(self.size,self.size),(self.fill,)*3)
        canvas.paste(img,((self.size-nw)//2,(self.size-nh)//2))
        return canvas

resize_pad = ResizePad(IMG_SIZE)
TF = transforms.Compose([
    resize_pad,
    transforms.ToTensor(),
    transforms.Normalize(
        [0.485,0.456,0.406],
        [0.229,0.224,0.225]
    )
])

seg = SmallUNet().to(DEVICE)
seg_obj = torch.load(
    MODELS/"prostate_segmenter.pt",
    map_location="cpu",
    weights_only=False
)
seg.load_state_dict(seg_obj["state_dict"], strict=True)
seg.eval()

def largest(mask):
    n,lab,stats,_ = cv2.connectedComponentsWithStats(mask.astype(np.uint8),8)
    if n <= 1:
        return mask.astype(np.uint8)
    return (lab == (1 + np.argmax(stats[1:,cv2.CC_STAT_AREA]))).astype(np.uint8)

@torch.inference_mode()
def segment_image(path):
    u = np.asarray(Image.open(path).convert("L"), dtype=np.uint8)
    r = cv2.resize(u, (SEG_SIZE,SEG_SIZE))
    x = torch.from_numpy(r.astype(np.float32)/255.0).view(1,1,SEG_SIZE,SEG_SIZE).to(DEVICE)
    p = torch.sigmoid(seg(x))[0,0].cpu().numpy()
    m = largest((p >= 0.5).astype(np.uint8))
    m = cv2.resize(m, (u.shape[1],u.shape[0]), interpolation=cv2.INTER_NEAREST)
    frac = float(m.mean())
    valid = MIN_MASK_FRAC <= frac <= MAX_MASK_FRAC
    if not valid:
        m = np.zeros_like(m)
    return u, m, valid, frac

def bbox_from_mask(mask, margin=ROI_MARGIN):
    ys,xs = np.where(mask > 0)
    if len(xs) == 0:
        return None
    x1,x2 = xs.min(),xs.max()+1
    y1,y2 = ys.min(),ys.max()+1
    bw=x2-x1; bh=y2-y1
    x1=max(0,int(x1-margin*bw)); x2=min(mask.shape[1],int(x2+margin*bw))
    y1=max(0,int(y1-margin*bh)); y2=min(mask.shape[0],int(y2+margin*bh))
    return x1,y1,x2,y2

def prepare_pil_from_arrays(u, mask, mode):
    if mode == "whole" or not mask.any():
        return Image.fromarray(u).convert("RGB")

    box = bbox_from_mask(mask)
    if box is None:
        return Image.fromarray(u).convert("RGB")
    x1,y1,x2,y2 = box

    if mode == "roi":
        out = u[y1:y2,x1:x2]
    elif mode == "masked_roi":
        q = u.copy()
        q[~mask.astype(bool)] = 0
        out = q[y1:y2,x1:x2]
    else:
        out = u

    return Image.fromarray(out).convert("RGB")

# ---------------------------------------------------------------------
# 4) exact fold assignment + fold models
# ---------------------------------------------------------------------
outer = StratifiedKFold(
    n_splits=5,
    shuffle=True,
    random_state=SEED
)

df["fold"] = -1
for fold, (_, te) in enumerate(outer.split(df, df["label"])):
    df.loc[te, "fold"] = fold

fold_models = {}
fold_specs = {}

for fold in range(5):
    p = MODELS/"trackb_folds"/f"fold_{fold}_model.pt"
    o = torch.load(p, map_location="cpu", weights_only=False)
    m = timm.create_model(
        str(o["backbone"]),
        pretrained=False,
        num_classes=1,
        drop_rate=float(o["dropout"])
    ).to(DEVICE)
    m.load_state_dict(o["state_dict"], strict=True)
    m.eval()
    fold_models[fold] = m
    fold_specs[fold] = {
        "backbone": str(o["backbone"]),
        "input_mode": str(o["input_mode"]),
        "dropout": float(o["dropout"]),
    }

print("Loaded exact validated Track-B fold models.")

# ---------------------------------------------------------------------
# 5) OOF inference + exact calibration
# ---------------------------------------------------------------------
raw_oof = np.full(len(df), np.nan, float)
mask_cache = {}

for i, r in df.iterrows():
    fold = int(r["fold"])
    model = fold_models[fold]
    mode = fold_specs[fold]["input_mode"]

    u,m,valid,frac = segment_image(r["path"])
    mask_cache[i] = (u,m,valid,frac)

    pil = prepare_pil_from_arrays(u,m,mode)
    x = TF(pil).unsqueeze(0).to(DEVICE)

    with torch.inference_mode():
        raw_oof[i] = float(torch.sigmoid(model(x).reshape(-1))[0].cpu())

    if (i+1) % 40 == 0:
        print(f"Internal OOF inference: {i+1}/{len(df)}")

# Locked Track-B replay calibration:
CAL_COEF = 0.596408690063814
CAL_INTERCEPT = 0.021206266053144414
LOCKED_THRESHOLD = 0.441200424654999

eps = 1e-6
lg = np.log(
    np.clip(raw_oof,eps,1-eps) /
    (1-np.clip(raw_oof,eps,1-eps))
)
pcal = 1/(1+np.exp(-(CAL_COEF*lg + CAL_INTERCEPT)))

y = df["label"].to_numpy(int)

# ---------------------------------------------------------------------
# 6) metrics
# ---------------------------------------------------------------------
def bootstrap_auc(y,p,B=5000,seed=20260914):
    rng=np.random.default_rng(seed)
    vals=[]
    for _ in range(B):
        ix=rng.integers(0,len(y),len(y))
        if len(np.unique(y[ix]))<2:
            continue
        vals.append(roc_auc_score(y[ix],p[ix]))
    return [
        float(np.percentile(vals,2.5)),
        float(np.percentile(vals,97.5))
    ]

pred = (pcal >= LOCKED_THRESHOLD).astype(int)
tn,fp,fn,tp = confusion_matrix(y,pred,labels=[0,1]).ravel()

metrics = {
    "analysis":"Track-B Replay — best internal OOF",
    "n":int(len(y)),
    "roc_auc":float(roc_auc_score(y,pcal)),
    "roc_auc_ci95":bootstrap_auc(y,pcal),
    "pr_auc_average_precision":float(average_precision_score(y,pcal)),
    "accuracy":float(accuracy_score(y,pred)),
    "sensitivity_recall":float(recall_score(y,pred)),
    "specificity":float(tn/(tn+fp)),
    "ppv_precision":float(precision_score(y,pred)),
    "npv":float(tn/(tn+fn)),
    "f1":float(f1_score(y,pred)),
    "brier":float(brier_score_loss(y,pcal)),
    "threshold":float(LOCKED_THRESHOLD),
    "tn":int(tn),"fp":int(fp),"fn":int(fn),"tp":int(tp),
}

# Hybrid reference, not the "best internal AUC" row.
hybrid_ref = None
hybrid_lock = ART/"HYBRID_SCIENTIFIC_LOCK.json"
if hybrid_lock.exists():
    h = json.load(open(hybrid_lock))
    hm = h.get("nested_internal_metrics",{})
    if hm:
        hybrid_ref = {
            "analysis":"B-v3 Hybrid nested meta-OOF (reference)",
            **hm
        }

json.dump(metrics, open(OUT/"BEST_INTERNAL_METRICS.json","w"), indent=2)

pd.DataFrame([metrics]).to_csv(
    OUT/"BEST_INTERNAL_PERFORMANCE_TABLE.csv",
    index=False
)

master_rows = [{
    "analysis":"Track-B Replay — best internal OOF",
    "roc_auc":metrics["roc_auc"],
    "pr_auc":metrics["pr_auc_average_precision"],
    "accuracy":metrics["accuracy"],
    "sensitivity":metrics["sensitivity_recall"],
    "specificity":metrics["specificity"],
    "ppv":metrics["ppv_precision"],
    "npv":metrics["npv"],
    "f1":metrics["f1"],
}]
if hybrid_ref:
    master_rows.append({
        "analysis":"B-v3 Hybrid nested meta-OOF",
        "roc_auc":hybrid_ref["roc_auc"],
        "pr_auc":hybrid_ref["pr_auc"],
        "accuracy":hybrid_ref["accuracy"],
        "sensitivity":hybrid_ref["sensitivity"],
        "specificity":hybrid_ref["specificity"],
        "ppv":hybrid_ref["ppv"],
        "npv":hybrid_ref["npv"],
        "f1":hybrid_ref["f1"],
    })
pd.DataFrame(master_rows).to_csv(
    OUT/"INTERNAL_MODEL_COMPARISON.csv",
    index=False
)

oof_export = df[[
    "path","class","label","sha256","color_overlay_fraction","fold"
]].copy()
oof_export["raw_oof_probability"] = raw_oof
oof_export["calibrated_oof_probability"] = pcal
oof_export["locked_prediction"] = pred
oof_export.to_csv(OUT/"BEST_INTERNAL_OOF_PREDICTIONS.csv",index=False)

print("\n=== BEST INTERNAL OOF PERFORMANCE ===")
for k in [
    "roc_auc","pr_auc_average_precision","accuracy",
    "sensitivity_recall","specificity",
    "ppv_precision","npv","f1","brier"
]:
    print(f"{k}: {metrics[k]:.3f}")
print("95% AUC CI:", [round(x,3) for x in metrics["roc_auc_ci95"]])
print("TN FP FN TP:", tn,fp,fn,tp)

# ---------------------------------------------------------------------
# 7) publication plots
# ---------------------------------------------------------------------
fpr,tpr,_ = roc_curve(y,pcal)
plt.figure(figsize=(6.3,5.4))
plt.plot(fpr,tpr,linewidth=2,label=f"Internal OOF AUC={metrics['roc_auc']:.3f}")
plt.plot([0,1],[0,1],"--",linewidth=1)
plt.xlabel("False positive rate")
plt.ylabel("True positive rate")
plt.title("Best internal OOF ROC — Track-B Replay")
plt.legend()
plt.grid(alpha=0.2)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_ROC.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_ROC.pdf",bbox_inches="tight")
plt.close()

precision,recall,_ = precision_recall_curve(y,pcal)
plt.figure(figsize=(6.3,5.4))
plt.plot(recall,precision,linewidth=2,
         label=f"Internal AP={metrics['pr_auc_average_precision']:.3f}")
plt.axhline(y.mean(),linestyle="--",linewidth=1)
plt.xlabel("Recall")
plt.ylabel("Precision")
plt.title("Best internal OOF precision–recall")
plt.legend()
plt.grid(alpha=0.2)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_PR.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_PR.pdf",bbox_inches="tight")
plt.close()

cm=np.array([[tn,fp],[fn,tp]])
fig,ax=plt.subplots(figsize=(5.3,4.7))
im=ax.imshow(cm)
for i in range(2):
    for j in range(2):
        ax.text(j,i,str(cm[i,j]),ha="center",va="center",fontsize=17)
ax.set_xticks([0,1],["Predicted normal","Predicted cancer"])
ax.set_yticks([0,1],["Actual normal","Actual cancer"])
ax.set_title(f"Internal OOF confusion matrix\nLocked threshold={LOCKED_THRESHOLD:.3f}")
fig.colorbar(im,ax=ax,fraction=0.046,pad=0.04)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_CONFUSION_MATRIX.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_CONFUSION_MATRIX.pdf",bbox_inches="tight")
plt.close()

prob_true,prob_pred = calibration_curve(y,pcal,n_bins=10,strategy="quantile")
plt.figure(figsize=(6.3,5.4))
plt.plot(prob_pred,prob_true,marker="o",linewidth=2)
plt.plot([0,1],[0,1],"--",linewidth=1)
plt.xlabel("Mean predicted probability")
plt.ylabel("Observed cancer fraction")
plt.title(f"Internal OOF calibration\nBrier={metrics['brier']:.3f}")
plt.grid(alpha=0.2)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_CALIBRATION.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_CALIBRATION.pdf",bbox_inches="tight")
plt.close()

# fold AUCs
fold_rows=[]
for fold in range(5):
    ix=np.where(df["fold"].to_numpy()==fold)[0]
    fold_rows.append({
        "fold":fold,
        "auc":float(roc_auc_score(y[ix],pcal[ix])),
        "n":int(len(ix))
    })
fold_df=pd.DataFrame(fold_rows)
fold_df.to_csv(OUT/"INTERNAL_FOLD_AUCS.csv",index=False)

plt.figure(figsize=(7,5))
plt.bar(fold_df["fold"].astype(str),fold_df["auc"])
plt.axhline(metrics["roc_auc"],linestyle="--",linewidth=1.5)
plt.ylim(0.5,1.0)
plt.xlabel("Validation fold")
plt.ylabel("ROC-AUC")
plt.title("Internal OOF performance across folds")
plt.grid(axis="y",alpha=0.2)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_FOLD_AUC.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_FOLD_AUC.pdf",bbox_inches="tight")
plt.close()

# operating metrics bar
ops = pd.DataFrame({
    "metric":["Accuracy","Sensitivity","Specificity","PPV","NPV","F1"],
    "value":[
        metrics["accuracy"],metrics["sensitivity_recall"],
        metrics["specificity"],metrics["ppv_precision"],
        metrics["npv"],metrics["f1"]
    ]
})
plt.figure(figsize=(8,5))
plt.bar(ops["metric"],ops["value"])
plt.ylim(0,1)
plt.ylabel("Metric value")
plt.title("Best internal OOF operating-point metrics")
plt.grid(axis="y",alpha=0.2)
plt.tight_layout()
plt.savefig(FIG/"INTERNAL_OPERATING_METRICS.png",dpi=350,bbox_inches="tight")
plt.savefig(FIG/"INTERNAL_OPERATING_METRICS.pdf",bbox_inches="tight")
plt.close()

# ---------------------------------------------------------------------
# 8) fold-specific INTERNAL Grad-CAM
# ---------------------------------------------------------------------
def last_conv2d(model):
    named = [(n,m) for n,m in model.named_modules() if isinstance(m,nn.Conv2d)]
    if not named:
        raise RuntimeError("No Conv2d layer found for Grad-CAM")
    return named[-1]

def gradcam_one(model, pil_prepared):
    model.eval()
    layer_name, layer = last_conv2d(model)
    act = {}
    grad = {}

    def fwd_hook(module, inp, out):
        act["v"] = out
        out.register_hook(lambda g: grad.__setitem__("v",g))

    handle = layer.register_forward_hook(fwd_hook)

    x = TF(pil_prepared).unsqueeze(0).to(DEVICE)
    model.zero_grad(set_to_none=True)
    logit = model(x).reshape(-1)[0]
    logit.backward()

    A = act["v"].detach()
    G = grad["v"].detach()
    handle.remove()

    if A.ndim != 4:
        raise RuntimeError(f"Grad-CAM target activation shape={tuple(A.shape)}")

    w = G.mean(dim=(2,3),keepdim=True)
    cam = torch.relu((w*A).sum(dim=1))[0].cpu().numpy()
    cam = cv2.resize(cam,(IMG_SIZE,IMG_SIZE),interpolation=cv2.INTER_CUBIC)
    cam = cam - cam.min()
    cam = cam/(cam.max()+1e-8)

    base = np.asarray(resize_pad(pil_prepared).convert("RGB"))
    heat = cv2.applyColorMap(np.uint8(255*cam),cv2.COLORMAP_JET)
    heat = cv2.cvtColor(heat,cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(base,0.62,heat,0.38,0)

    prob = float(torch.sigmoid(logit).detach().cpu())
    return base, cam, overlay, prob, layer_name

oof_export["category"] = np.select(
    [
        (oof_export.label==1)&(oof_export.locked_prediction==1),
        (oof_export.label==0)&(oof_export.locked_prediction==0),
        (oof_export.label==0)&(oof_export.locked_prediction==1),
        (oof_export.label==1)&(oof_export.locked_prediction==0),
    ],
    ["TP","TN","FP","FN"],
    default="OTHER"
)

chosen=[]
for cat,n_take in [("TP",2),("TN",2),("FP",1),("FN",1)]:
    g=oof_export[oof_export["category"]==cat].copy()
    if len(g)==0:
        continue
    g["h"]=g["sha256"].map(
        lambda s: hashlib.sha256(("INTERNAL_GRADCAM|"+s).encode()).hexdigest()
    )
    chosen += g.sort_values("h").head(n_take).to_dict("records")

cam_rows=[]

for r in chosen:
    idx = int(r["path"] in [])  # dummy to keep lint quiet
    # Find original dataframe row by SHA
    ii = int(df.index[df["sha256"]==r["sha256"]][0])
    fold = int(df.loc[ii,"fold"])
    model = fold_models[fold]
    spec = fold_specs[fold]
    u,m,valid,frac = mask_cache[ii]
    prepared = prepare_pil_from_arrays(u,m,spec["input_mode"])

    print("Internal Grad-CAM:",r["category"],"fold",fold,Path(r["path"]).name)

    try:
        base,cam,overlay,p_direct,layer_name = gradcam_one(model,prepared)

        fig,ax=plt.subplots(1,3,figsize=(12,4.2))
        ax[0].imshow(base); ax[0].set_title("Model input"); ax[0].axis("off")
        ax[1].imshow(cam,cmap="jet"); ax[1].set_title("Grad-CAM"); ax[1].axis("off")
        ax[2].imshow(overlay); ax[2].set_title("Overlay"); ax[2].axis("off")

        fig.suptitle(
            f"{r['category']} | fold={fold} | {spec['backbone']} | {spec['input_mode']}\n"
            f"OOF calibrated p={r['calibrated_oof_probability']:.3f} | truth={int(r['label'])}",
            fontsize=11
        )
        plt.tight_layout()

        stem=f"INTERNAL_GRADCAM_{r['category']}_fold{fold}_{r['sha256'][:8]}"
        plt.savefig(FIG/f"{stem}.png",dpi=300,bbox_inches="tight")
        plt.savefig(FIG/f"{stem}.pdf",bbox_inches="tight")
        plt.close()

        cam_rows.append({
            "sha256":r["sha256"],
            "category":r["category"],
            "truth":int(r["label"]),
            "fold":fold,
            "backbone":spec["backbone"],
            "input_mode":spec["input_mode"],
            "oof_calibrated_probability":float(r["calibrated_oof_probability"]),
            "direct_fold_probability":p_direct,
            "gradcam_target_layer":layer_name,
            "mask_valid":bool(valid),
            "mask_fraction":float(frac),
        })
    except Exception as e:
        cam_rows.append({
            "sha256":r["sha256"],
            "category":r["category"],
            "fold":fold,
            "error":repr(e)
        })

    if DEVICE=="cuda":
        torch.cuda.empty_cache()
    gc.collect()

pd.DataFrame(cam_rows).to_csv(
    OUT/"INTERNAL_GRADCAM_MANIFEST.csv",
    index=False
)

# ---------------------------------------------------------------------
# 9) paper-ready summary
# ---------------------------------------------------------------------
summary = f"""# Agent B — Best Internal Performance

## Primary internal result
The highest internal ROC-AUC was obtained by the Track-B replay using
five-fold out-of-fold evaluation on the approved 243-image institutional cohort.

- ROC-AUC: {metrics['roc_auc']:.3f}
- 95% CI: {metrics['roc_auc_ci95'][0]:.3f}–{metrics['roc_auc_ci95'][1]:.3f}
- PR-AUC / Average Precision: {metrics['pr_auc_average_precision']:.3f}
- Accuracy: {metrics['accuracy']:.3f}
- Sensitivity: {metrics['sensitivity_recall']:.3f}
- Specificity: {metrics['specificity']:.3f}
- PPV: {metrics['ppv_precision']:.3f}
- NPV: {metrics['npv']:.3f}
- F1: {metrics['f1']:.3f}
- Brier score: {metrics['brier']:.3f}
- Locked threshold: {metrics['threshold']:.3f}
- Confusion matrix: TN={tn}, FP={fp}, FN={fn}, TP={tp}

## Interpretation
All performance values are out-of-fold internal estimates.
The Grad-CAM examples use the validation-fold model assigned to each case,
rather than a model trained on that case.

## Reporting role
Track-B replay is the highest-AUC internal result.
The B-v3 hybrid is retained as a separate balanced/generalization-oriented
development model and should not be conflated with the highest internal AUC.
"""
(OUT/"BEST_INTERNAL_PAPER_SUMMARY.md").write_text(summary,encoding="utf-8")

zip_path = shutil.make_archive(
    "/content/AgentB_BEST_INTERNAL_Performance_GradCAM",
    "zip",
    OUT
)

print("\n"+"="*78)
print("✅ BEST INTERNAL PERFORMANCE + INTERNAL GRAD-CAM COMPLETE")
print("Internal OOF ROC-AUC:",round(metrics["roc_auc"],3))
print("Internal PR-AUC:",round(metrics["pr_auc_average_precision"],3))
print("Accuracy:",round(metrics["accuracy"],3))
print("Sensitivity:",round(metrics["sensitivity_recall"],3))
print("Specificity:",round(metrics["specificity"],3))
print("PPV:",round(metrics["ppv_precision"],3))
print("NPV:",round(metrics["npv"],3))
print("F1:",round(metrics["f1"],3))
print("Grad-CAM exemplars:",len(cam_rows))
print("="*78)
print("ZIP:",zip_path)

try:
    from google.colab import files
    files.download(zip_path)
except Exception:
    pass

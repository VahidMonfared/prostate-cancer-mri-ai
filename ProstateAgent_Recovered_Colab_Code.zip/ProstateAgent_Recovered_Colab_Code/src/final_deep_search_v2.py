from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.special import expit, logit
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import ExtraTreesRegressor, GradientBoostingRegressor, HistGradientBoostingRegressor, RandomForestRegressor, VotingRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.kernel_ridge import KernelRidge
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, RandomizedSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, SplineTransformer, StandardScaler
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
import joblib

ROOT=Path('analysis_input'); OUT=Path('final_search_v2'); OUT.mkdir(exist_ok=True)
e=pd.read_csv(ROOT/'interpretable_engineered_features.csv')
s=pd.read_csv(ROOT/'SAE_CONCEPT_FEATURES.csv')
d=e.merge(s,on='patient_id',validate='one_to_one')
ids=d.pop('patient_id').to_numpy(); y=d.pop('teacher_probability').to_numpy(float)
names=np.asarray(d.columns,dtype=str); X=d.to_numpy(float)

def lg(y): return logit(np.clip(y,1e-5,1-1e-5))
def ex(z): return expit(z)

class LinearLeafTree(BaseEstimator,RegressorMixin):
    def __init__(self,max_depth=3,min_samples_leaf=20,alpha=10.0):
        self.max_depth=max_depth; self.min_samples_leaf=min_samples_leaf; self.alpha=alpha
    def fit(self,X,y):
        X=np.asarray(X,float); y=np.asarray(y,float)
        self.tree_=DecisionTreeRegressor(max_depth=self.max_depth,min_samples_leaf=self.min_samples_leaf,
            random_state=20260918).fit(X,y)
        leaves=self.tree_.apply(X); self.models_={}; self.global_=Ridge(alpha=self.alpha).fit(X,y)
        for leaf in np.unique(leaves):
            q=leaves==leaf
            if q.sum()>=max(8,X.shape[1]//3): self.models_[int(leaf)]=Ridge(alpha=self.alpha).fit(X[q],y[q])
        return self
    def predict(self,X):
        X=np.asarray(X,float); leaves=self.tree_.apply(X); p=np.empty(len(X))
        for leaf in np.unique(leaves):
            q=leaves==leaf; p[q]=self.models_.get(int(leaf),self.global_).predict(X[q])
        return np.clip(p,0,1)

common=[('imp',SimpleImputer(strategy='median')),('sel',SelectKBest(f_regression))]
families={
 'extra_trees':(
   Pipeline(common+[('model',ExtraTreesRegressor(random_state=20260918,n_jobs=-1))]),
   {'sel__k':[30,60,100,'all'],'model__n_estimators':[500],'model__max_features':[.35,.6,1.0],
    'model__min_samples_leaf':[2,4,7],'model__max_depth':[None,8,14]}),
 'random_forest_logit':(
   Pipeline(common+[('model',TransformedTargetRegressor(
       regressor=RandomForestRegressor(random_state=20260918,n_jobs=-1,n_estimators=500),func=lg,inverse_func=ex,check_inverse=False))]),
   {'sel__k':[30,60,100,'all'],'model__regressor__max_features':[.35,.6,1.0],
    'model__regressor__min_samples_leaf':[2,4,7],'model__regressor__max_depth':[None,8,14]}),
 'hist_gradient_logit':(
   Pipeline(common+[('model',TransformedTargetRegressor(
       regressor=HistGradientBoostingRegressor(random_state=20260918),func=lg,inverse_func=ex,check_inverse=False))]),
   {'sel__k':[30,60,100,'all'],'model__regressor__learning_rate':[.025,.05,.08],
    'model__regressor__max_iter':[300,600],'model__regressor__max_leaf_nodes':[5,9,15],
    'model__regressor__l2_regularization':[.1,1,5],'model__regressor__min_samples_leaf':[10,20,30]}),
 'gradient_boosting':(
   Pipeline(common+[('model',GradientBoostingRegressor(random_state=20260918,loss='huber'))]),
   {'sel__k':[20,40,80],'model__n_estimators':[150,300,500],'model__learning_rate':[.02,.04,.07],
    'model__max_depth':[1,2,3],'model__min_samples_leaf':[8,15,25],'model__subsample':[.7,1.0]}),
 'rbf_svr':(
   Pipeline(common+[('scale',StandardScaler()),('model',SVR(kernel='rbf'))]),
   {'sel__k':[20,40,80,'all'],'model__C':[.1,.3,1,3,10],'model__gamma':['scale',.001,.003,.01,.03],
    'model__epsilon':[.02,.04,.07]}),
 'linear_leaf_tree':(
   Pipeline(common+[('scale',StandardScaler()),('model',LinearLeafTree())]),
   {'sel__k':[8,12,20,30],'model__max_depth':[2,3,4],'model__min_samples_leaf':[12,18,25,32],
    'model__alpha':[.1,1,10,50]}),
 'spline_formula':(
   Pipeline(common+[('spline',SplineTransformer(include_bias=False)),('scale',StandardScaler()),('model',Ridge())]),
   {'sel__k':[6,10,14,20],'spline__n_knots':[3,4,5,6],'spline__degree':[2,3],
    'model__alpha':[1,10,50,100,300]}),
 'dense_polynomial_formula':(
   Pipeline(common+[('poly',PolynomialFeatures(degree=2,include_bias=False)),('scale',StandardScaler()),('model',Ridge())]),
   {'sel__k':[6,8,10,12,15],'model__alpha':[10,30,100,300,1000]}),
}

outer=KFold(5,shuffle=True,random_state=20260918)
preds={k:np.zeros(len(y)) for k in families}; params={k:[] for k in families}
for fold,(tr,te) in enumerate(outer.split(X),1):
    inner=KFold(4,shuffle=True,random_state=20260918+fold)
    for name,(pipe,grid) in families.items():
        gs=RandomizedSearchCV(pipe,grid,n_iter=24,scoring='r2',cv=inner,n_jobs=-1,
                            random_state=20260918+fold,error_score='raise')
        gs.fit(X[tr],y[tr]); preds[name][te]=np.clip(gs.predict(X[te]),0,1)
        params[name].append(gs.best_params_)
        print(fold,name,gs.best_score_,flush=True)

# Cross-fitted stacking of pre-existing OOF predictions; meta learner never sees its evaluation fold.
base=pd.read_csv(ROOT/'R2_BOOSTER_v3'/'R2_BOOSTER_OOF_PREDICTIONS.csv')
base=base.set_index('patient_id').loc[ids]
Z=base[['v3_neural_bag_student_oof','v2_concept_stack_oof','v3_classical_stack_oof']].to_numpy(float)
stack=np.zeros(len(y)); blend=np.zeros(len(y))
for fold,(tr,te) in enumerate(outer.split(Z),1):
    # Positive ridge produces a stable auditable linear ensemble.
    meta=Ridge(alpha=1.0,positive=True).fit(Z[tr],y[tr])
    stack[te]=np.clip(meta.predict(Z[te]),0,1)
    # Fixed 70/30 blend was chosen from prior experiments, not this fold.
    blend[te]=.70*Z[te,0]+.30*Z[te,1]
preds['cross_fitted_ridge_stack']=stack; preds['fixed_70_30_neural_concept_blend']=blend

rows=[]
for name,p in preds.items():
    rows.append({'model':name,'r2':r2_score(y,p),'mae':mean_absolute_error(y,p),
                 'pearson_r':np.corrcoef(y,p)[0,1],'agreement_0.5':np.mean((y>=.5)==(p>=.5))})
pd.DataFrame(rows).sort_values('r2',ascending=False).to_csv(OUT/'FINAL_SEARCH_OOF_METRICS.csv',index=False)
pd.DataFrame({'patient_id':ids,'teacher_probability':y,**preds}).to_csv(OUT/'FINAL_SEARCH_OOF_PREDICTIONS.csv',index=False)
(OUT/'FINAL_SEARCH_INNER_PARAMS.json').write_text(json.dumps(params,indent=2,default=str))

# Refit each model with the modal parameter set for executable artifacts.
for name,(pipe,grid) in families.items():
    votes=params[name]
    keys=sorted(votes[0]); choices={k:max({str(v.get(k)):sum(str(x.get(k))==str(v.get(k)) for x in votes) for v in votes}.items(),key=lambda z:z[1])[0] for k in keys}
    # recover actual typed value from first matching fold
    chosen={k:next(v[k] for v in votes if str(v[k])==choices[k]) for k in keys}
    pipe.set_params(**chosen).fit(X,y); joblib.dump(pipe,OUT/f'{name}.joblib')
    (OUT/f'{name}_modal_params.json').write_text(json.dumps(chosen,indent=2,default=str))
print(pd.DataFrame(rows).sort_values('r2',ascending=False).to_string(index=False))

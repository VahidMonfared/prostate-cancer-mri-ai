
# UCLA B-v6 FINAL SQUEEZE — exploratory post-hoc sensitivity analysis
# Run in the SAME Colab where B-v6 PRO is already restored.
#
# Required in /content:
#   Prostate_T2_Agent_B_v6_Fast_FINAL_RESULTS.zip
#
# What it does:
# - re-downloads the SAME 133 UCLA holdout series (~1.3 GB total)
# - does NOT retrain any weights
# - uses a fixed 16-view label-free TTA:
#     4 spatial slice-selection strategies × 4 intensity transforms
# - combines all views with equal-logit averaging
# - reads the already-known labels only AFTER predictions are written
#
# IMPORTANT:
# This is NOT a new untouched external validation because this UCLA cohort
# has already been evaluated. If performance improves, report it only as
# an exploratory/post-hoc multiview sensitivity analysis.
# Keep the original 0.717 as the primary held-out result.

import os, re, gc, json, math, shutil, zipfile, hashlib, subprocess, sys
from pathlib import Path
from contextlib import nullcontext

import numpy as np
import pandas as pd
import torch
import SimpleITK as sitk
import cv2
from sklearn.metrics import roc_auc_score, average_precision_score

# ------------------------------------------------------------
# 0) REQUIRE CURRENT RESTORED MODEL
# ------------------------------------------------------------
required = ["bv3","bv3proc","models","dino_batch_u8","DEVICE"]
missing = [x for x in required if x not in globals()]
if missing:
    raise RuntimeError(
        "B-v6 PRO must already be restored in this runtime. Missing: "
        + ", ".join(missing)
    )

try:
    from idc_index import IDCClient
except Exception:
    subprocess.run(
        [sys.executable,"-m","pip","install","-q","idc-index"],
        check=True
    )
    from idc_index import IDCClient

ZIP = Path("/content/Prostate_T2_Agent_B_v6_Fast_FINAL_RESULTS.zip")
if not ZIP.exists():
    raise FileNotFoundError(
        "Upload Prostate_T2_Agent_B_v6_Fast_FINAL_RESULTS.zip to /content"
    )

ROOT = Path("/content/BV6_UCLA_FINAL_SQUEEZE")
DICOM_DIR = ROOT/"dicom"
RES = ROOT/"results"
for p in [ROOT,DICOM_DIR,RES]:
    p.mkdir(parents=True, exist_ok=True)

# ------------------------------------------------------------
# 1) LOAD ONLY COHORT LOCK — DO NOT READ LABELS YET
# ------------------------------------------------------------
with zipfile.ZipFile(ZIP) as z:
    lock_name = next(
        n for n in z.namelist()
        if n.endswith("BV6_FRESH_UCLA_TEST_PRETRAIN.csv")
    )
    with z.open(lock_name) as f:
        cohort = pd.read_csv(f)

cohort["mr_uid"] = cohort["mr_uid"].astype(str).str.strip()
cohort["patient_key"] = cohort["patient_key"].astype(str).str.strip()

print("UCLA holdout N:", len(cohort))
print("Estimated DICOM transfer GB:",
      round(pd.to_numeric(cohort["series_size_MB"],errors="coerce").fillna(0).sum()/1024,2))

# ------------------------------------------------------------
# 2) DOWNLOAD SAME 133 T2 SERIES (~1.3GB)
# ------------------------------------------------------------
client = IDCClient.client()

def series_has_files(uid):
    d = DICOM_DIR/uid
    return d.exists() and any(p.is_file() for p in d.rglob("*"))

def download_batch(uids, source="aws"):
    client.download_dicom_series(
        seriesInstanceUID=list(uids),
        downloadDir=str(DICOM_DIR),
        quiet=False,
        show_progress_bar=True,
        use_s5cmd_sync=True,
        dirTemplate="%SeriesInstanceUID",
        source_bucket_location=source
    )

uids = cohort["mr_uid"].tolist()
for start in range(0,len(uids),25):
    need = [u for u in uids[start:start+25] if not series_has_files(u)]
    if not need:
        continue
    print("Downloading:", start+1, "-", min(start+25,len(uids)))
    try:
        download_batch(need,"aws")
    except Exception:
        try:
            download_batch(need,"gcs")
        except Exception:
            for u in need:
                try:
                    download_batch([u],"aws")
                except Exception:
                    try:
                        download_batch([u],"gcs")
                    except Exception as e:
                        print("download failed:",u,repr(e))

# ------------------------------------------------------------
# 3) DICOM VOLUME READER
# ------------------------------------------------------------
def read_dicom_volume(series_dir):
    series_dir = str(series_dir)
    ids = sitk.ImageSeriesReader.GetGDCMSeriesIDs(series_dir)

    if ids:
        groups=[]
        for sid in ids:
            fs = sitk.ImageSeriesReader.GetGDCMSeriesFileNames(series_dir,sid)
            groups.append((len(fs),fs))
        files = max(groups,key=lambda x:x[0])[1]
    else:
        files = sorted(
            str(p) for p in Path(series_dir).rglob("*")
            if p.is_file()
        )

    if not files:
        raise RuntimeError("No DICOM files")

    r = sitk.ImageSeriesReader()
    r.SetFileNames(files)
    img = r.Execute()

    try:
        img = sitk.DICOMOrient(img,"LPS")
    except Exception:
        pass

    a = np.squeeze(sitk.GetArrayFromImage(img))

    if a.ndim == 2:
        a = a[None,...]

    if a.ndim != 3:
        raise RuntimeError(f"Unexpected volume shape {a.shape}")

    return a.astype(np.float32)

# ------------------------------------------------------------
# 4) FIXED 16-VIEW TTA — NO LABEL-BASED WEIGHTS
# ------------------------------------------------------------
K = 12

def prepare_slices(vol):
    slices = [bv3proc.robust_uint8(vol[z]) for z in range(vol.shape[0])]
    masks, valid = bv3.segment(slices)
    areas = np.array([
        float(m.sum()) if v else 0.0
        for m,v in zip(masks,valid)
    ], dtype=float)
    return slices,masks,valid,areas

def pad_idx(idx,k=K):
    idx=np.asarray(idx,int)
    if len(idx)==0:
        idx=np.array([0],int)
    while len(idx)<k:
        idx=np.r_[idx,idx[-1]]
    return idx[:k]

def spatial_views(areas,n,k=K):
    # 1) top gland-area slices
    if areas.max()>0:
        top=np.sort(np.argsort(-areas)[:min(k,n)])
        center=int(np.argmax(areas))
    else:
        center=n//2
        top=np.arange(max(0,center-k//2),min(n,center+(k+1)//2))
    top=pad_idx(top,k)

    # 2) contiguous around max gland area
    lo=max(0,center-k//2)
    hi=min(n,lo+k)
    lo=max(0,hi-k)
    contiguous=pad_idx(np.arange(lo,hi),k)

    # 3) even spacing across gland-positive extent
    nz=np.where(areas>0)[0]
    if len(nz)>=2:
        even=np.round(np.linspace(nz.min(),nz.max(),k)).astype(int)
    else:
        even=contiguous.copy()
    even=pad_idx(even,k)

    # 4) quantile slices weighted by gland area
    if areas.sum()>0:
        cdf=np.cumsum(areas)/areas.sum()
        qs=np.linspace(0.08,0.92,k)
        quant=np.array([np.searchsorted(cdf,q) for q in qs],int)
        quant=np.clip(quant,0,n-1)
    else:
        quant=contiguous.copy()
    quant=pad_idx(quant,k)

    return [top,contiguous,even,quant]

def intensity_variant(u, mode):
    u=np.asarray(u,dtype=np.uint8)

    if mode=="original":
        return u

    if mode=="clahe":
        return cv2.createCLAHE(
            clipLimit=2.0,
            tileGridSize=(8,8)
        ).apply(u)

    x=u.astype(np.float32)/255.0

    if mode=="gamma085":
        y=np.power(x,0.85)
        return np.round(np.clip(y,0,1)*255).astype(np.uint8)

    if mode=="gamma115":
        y=np.power(x,1.15)
        return np.round(np.clip(y,0,1)*255).astype(np.uint8)

    raise ValueError(mode)

MODES=["original","clahe","gamma085","gamma115"]

@torch.inference_mode()
def fold_prob_from_bag(bag):
    x=torch.tensor(
        bag[None,...],
        dtype=torch.float32,
        device=DEVICE
    )
    fp=np.asarray([
        torch.sigmoid(m(x)[0]).item()
        for m in models
    ], dtype=float)
    return fp

def logit(p):
    p=np.clip(np.asarray(p,float),1e-6,1-1e-6)
    return np.log(p/(1-p))

def sigmoid(x):
    return 1/(1+np.exp(-x))

@torch.inference_mode()
def predict_16view(vol):
    slices,masks,valid,areas=prepare_slices(vol)
    idx_views=spatial_views(areas,len(slices),K)

    # cache DINO features for every unique (slice, intensity) pair
    unique_idx=sorted(set(int(z) for idx in idx_views for z in idx))
    feature_cache={}

    for mode in MODES:
        imgs=[]
        keys=[]

        for z in unique_idx:
            u=slices[z]

            if valid[z] and np.asarray(masks[z]).any():
                try:
                    u=bv3proc.crop_roi(u,masks[z])
                except Exception:
                    pass

            u=intensity_variant(u,mode)
            imgs.append(u)
            keys.append((mode,z))

        feats=[]
        for s in range(0,len(imgs),32):
            feats.append(dino_batch_u8(imgs[s:s+32]))
        feats=np.concatenate(feats,axis=0)

        for key,f in zip(keys,feats):
            feature_cache[key]=f.astype(np.float32)

    view_probs=[]
    fold_all=[]

    for idx in idx_views:
        for mode in MODES:
            bag=np.stack(
                [feature_cache[(mode,int(z))] for z in idx],
                axis=0
            ).astype(np.float32)

            fp=fold_prob_from_bag(bag)
            fold_all.extend(fp.tolist())
            view_probs.append(float(fp.mean()))

    # fixed equal-logit fusion
    tta=float(sigmoid(np.mean(logit(view_probs))))

    # baseline exactly corresponds to top-area + original
    baseline=float(view_probs[0])

    # label-free disagreement for optional selective analysis
    uncertainty=float(np.std(view_probs))

    return baseline,tta,uncertainty,view_probs

# ------------------------------------------------------------
# 5) PREDICT ALL CASES BEFORE READING SAVED LABEL FILE
# ------------------------------------------------------------
progress = RES/"UCLA_16VIEW_PROGRESS.csv"
if progress.exists():
    prev=pd.read_csv(progress)
    done=set(prev["patient_key"].astype(str))
    rows=prev.to_dict("records")
    print("Resuming from:",len(rows))
else:
    done=set()
    rows=[]

fails=[]

for i,r in cohort.reset_index(drop=True).iterrows():
    pid=str(r.patient_key)
    uid=str(r.mr_uid)

    if pid in done:
        continue

    print(f"Case {i+1}/{len(cohort)}: {pid}")

    try:
        vol=read_dicom_volume(DICOM_DIR/uid)
        pb,p16,unc,vps=predict_16view(vol)

        rows.append({
            "patient_key":pid,
            "mr_uid":uid,
            "baseline_probability":pb,
            "tta16_probability":p16,
            "tta_uncertainty":unc,
            "view_probabilities":json.dumps(vps)
        })

        pd.DataFrame(rows).to_csv(progress,index=False)

    except Exception as e:
        fails.append({
            "patient_key":pid,
            "mr_uid":uid,
            "error":repr(e)
        })

    if DEVICE=="cuda":
        torch.cuda.empty_cache()
    gc.collect()

pred=pd.DataFrame(rows)
pd.DataFrame(fails).to_csv(RES/"technical_failures.csv",index=False)

if len(pred)<120:
    raise RuntimeError(f"Only {len(pred)} predictions succeeded.")

pred_file=RES/"UCLA_16VIEW_PREDICTIONS_BEFORE_LABEL_READ.csv"
pred.to_csv(pred_file,index=False)
pred_sha=hashlib.sha256(pred_file.read_bytes()).hexdigest()
print("✅ Predictions complete:",len(pred))
print("Prediction SHA256:",pred_sha)

# ------------------------------------------------------------
# 6) NOW READ ALREADY-EXISTING UCLA LABELS FROM OLD RESULT ZIP
# ------------------------------------------------------------
with zipfile.ZipFile(ZIP) as z:
    label_name=next(
        n for n in z.namelist()
        if n.endswith("BV6_FRESH_UCLA_FINAL_WITH_PATHOLOGY.csv")
    )
    with z.open(label_name) as f:
        lab=pd.read_csv(f)

lab["patient_key"]=lab["patient_key"].astype(str)
final=pred.merge(
    lab[["patient_key","any_cancer","any_cspca"]],
    on="patient_key",
    how="inner",
    validate="one_to_one"
)

# ------------------------------------------------------------
# 7) METRICS
# ------------------------------------------------------------
def auc_ci(y,p,B=5000,seed=20260913):
    y=np.asarray(y,int)
    p=np.asarray(p,float)
    rng=np.random.default_rng(seed)
    vals=[]

    for _ in range(B):
        ix=rng.integers(0,len(y),len(y))
        if len(np.unique(y[ix]))<2:
            continue
        vals.append(roc_auc_score(y[ix],p[ix]))

    return [
        float(np.percentile(vals,2.5)),
        float(np.percentile(vals,97.5))
    ]

def calc(df,col,label="any_cancer"):
    y=df[label].astype(int).to_numpy()
    p=df[col].astype(float).to_numpy()
    return {
        "n":int(len(df)),
        "auc":float(roc_auc_score(y,p)),
        "ci95":auc_ci(y,p),
        "pr_auc":float(average_precision_score(y,p))
    }

baseline=calc(final,"baseline_probability")
tta=calc(final,"tta16_probability")

# fixed label-free 90% coverage secondary analysis
n90=int(np.ceil(0.90*len(final)))
sel=final.sort_values("tta_uncertainty").head(n90).copy()
tta90=calc(sel,"tta16_probability")

report={
    "status":"EXPLORATORY_POSTHOC_SENSITIVITY_ANALYSIS",
    "primary_original_heldout_auc":0.7168141592920353,
    "baseline_recomputed":baseline,
    "fixed_16view_tta":tta,
    "fixed_90pct_low_uncertainty":tta90,
    "test_labels_used_for_tta_weighting":False,
    "backbone_retrained":False,
    "head_retrained":False,
    "same_ucla_holdout_as_original_bv6":True,
    "prediction_sha256":pred_sha
}

json.dump(
    report,
    open(RES/"UCLA_16VIEW_EXPLORATORY_METRICS.json","w"),
    indent=2
)
final.to_csv(RES/"UCLA_16VIEW_FINAL_CASES.csv",index=False)

print("\n"+"="*72)
print("UCLA B-v6 FINAL SQUEEZE — EXPLORATORY / POST-HOC")
print("Do NOT replace the original 0.717 primary held-out result.")
print("\nOriginal published-candidate primary AUC: 0.717")
print(
    "Recomputed baseline AUC:",
    round(baseline["auc"],3),
    f"CI {baseline['ci95'][0]:.3f}-{baseline['ci95'][1]:.3f}"
)
print(
    "Fixed 16-view TTA AUC:",
    round(tta["auc"],3),
    f"CI {tta['ci95'][0]:.3f}-{tta['ci95'][1]:.3f}"
)
print(
    "90% low-uncertainty TTA AUC:",
    round(tta90["auc"],3),
    f"N={tta90['n']}"
)
print("="*72)

EXPORT=Path("/content/UCLA_BV6_FINAL_SQUEEZE")
shutil.rmtree(EXPORT,ignore_errors=True)
shutil.copytree(RES,EXPORT)
zip_path=shutil.make_archive(str(EXPORT),"zip",EXPORT)

print("\n✅ COMPLETE")
print(zip_path)

try:
    from google.colab import files
    files.download(zip_path)
except Exception:
    pass

from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, RegressorMixin, clone
from sklearn.compose import TransformedTargetRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import ElasticNet, Ridge
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GridSearchCV, KFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, RobustScaler, SplineTransformer, StandardScaler
from sklearn.tree import DecisionTreeRegressor, export_text, plot_tree
from sklearn.ensemble import GradientBoostingRegressor, ExtraTreesRegressor, RandomForestRegressor


ROOT = Path("analysis_input")
OUT = Path("interpretable_booster_results")
OUT.mkdir(exist_ok=True)
SEED = 20260918


class LinearLeafTree(BaseEstimator, RegressorMixin):
    """Axis-aligned tree whose leaves contain ridge-linear equations."""

    def __init__(self, max_depth=3, min_samples_leaf=25, alpha=10.0):
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.alpha = alpha

    def fit(self, X, y):
        X = np.asarray(X, dtype=float)
        y = np.asarray(y, dtype=float)
        self.tree_ = DecisionTreeRegressor(
            max_depth=self.max_depth,
            min_samples_leaf=self.min_samples_leaf,
            random_state=SEED,
        ).fit(X, y)
        leaves = self.tree_.apply(X)
        self.leaf_models_ = {}
        self.global_model_ = Ridge(alpha=self.alpha).fit(X, y)
        for leaf in np.unique(leaves):
            idx = leaves == leaf
            if idx.sum() >= max(8, X.shape[1] // 3):
                self.leaf_models_[int(leaf)] = Ridge(alpha=self.alpha).fit(X[idx], y[idx])
        return self

    def predict(self, X):
        X = np.asarray(X, dtype=float)
        leaves = self.tree_.apply(X)
        pred = np.empty(len(X), dtype=float)
        for leaf in np.unique(leaves):
            idx = leaves == leaf
            model = self.leaf_models_.get(int(leaf), self.global_model_)
            pred[idx] = model.predict(X[idx])
        return np.clip(pred, 0.0, 1.0)


def metrics(y, p):
    return {
        "r2": float(r2_score(y, p)),
        "mae": float(mean_absolute_error(y, p)),
        "pearson_r": float(np.corrcoef(y, p)[0, 1]),
        "agreement_0p5": float(np.mean((y >= 0.5) == (p >= 0.5))),
    }


def nested_oof(estimator, grid, X, y):
    outer = KFold(n_splits=5, shuffle=True, random_state=SEED)
    pred = np.zeros(len(y), dtype=float)
    params = []
    for fold, (tr, te) in enumerate(outer.split(X), 1):
        inner = KFold(n_splits=4, shuffle=True, random_state=SEED + fold)
        search = GridSearchCV(estimator, grid, scoring="r2", cv=inner, n_jobs=-1, refit=True)
        search.fit(X[tr], y[tr])
        pred[te] = search.predict(X[te])
        params.append(search.best_params_)
    return np.clip(pred, 0.0, 1.0), params


eng = pd.read_csv(ROOT / "interpretable_engineered_features.csv")
sae = pd.read_csv(ROOT / "SAE_CONCEPT_FEATURES.csv")
df = eng.merge(sae, on="patient_id", validate="one_to_one")
y = df.pop("teacher_probability").to_numpy(float)
ids = df.pop("patient_id").to_numpy()
feature_names = np.array(df.columns)
X = df.to_numpy(float)

# Screen features inside each CV training fold. This retains interpretability while
# preventing selection on held-out patients.
base_steps = [("impute", SimpleImputer(strategy="median")), ("select", SelectKBest(f_regression))]

formula = Pipeline(base_steps + [
    ("scale", StandardScaler()),
    ("poly", PolynomialFeatures(degree=2, include_bias=False)),
    ("enet", ElasticNet(max_iter=100000, random_state=SEED)),
])
formula_grid = {
    "select__k": [8, 12, 16, 24],
    "enet__alpha": [0.0005, 0.001, 0.002, 0.004, 0.008, 0.015],
    "enet__l1_ratio": [0.5, 0.7, 0.85, 0.95],
}

spline = Pipeline(base_steps + [
    ("spline", SplineTransformer(include_bias=False)),
    ("scale", StandardScaler()),
    ("ridge", Ridge()),
])
spline_grid = {
    "select__k": [6, 8, 12, 16, 24],
    "spline__n_knots": [3, 4, 5],
    "spline__degree": [1, 2, 3],
    "ridge__alpha": [1.0, 3.0, 10.0, 30.0, 100.0],
}

plain_tree = Pipeline(base_steps + [("tree", DecisionTreeRegressor(random_state=SEED))])
plain_tree_grid = {
    "select__k": [6, 8, 12, 16, 24],
    "tree__max_depth": [3, 4, 5, 6, 7, 8],
    "tree__min_samples_leaf": [6, 10, 15, 20, 25, 30],
    "tree__ccp_alpha": [0.0, 0.0001, 0.0003, 0.001],
}

model_tree = Pipeline(base_steps + [("scale", StandardScaler()), ("model", LinearLeafTree())])
model_tree_grid = {
    "select__k": [6, 8, 12, 16, 24],
    "model__max_depth": [1, 2, 3, 4],
    "model__min_samples_leaf": [20, 30, 40, 50],
    "model__alpha": [1.0, 3.0, 10.0, 30.0, 100.0],
}

boosted_rules = Pipeline(base_steps + [("boost", GradientBoostingRegressor(random_state=SEED))])
boosted_rules_grid = {
    "select__k": [8, 12, 16, 24, 36],
    "boost__n_estimators": [25, 50, 75, 100],
    "boost__learning_rate": [0.02, 0.05, 0.1],
    "boost__max_depth": [1, 2],
    "boost__min_samples_leaf": [10, 20, 30],
    "boost__loss": ["squared_error", "huber"],
}

specs = {
    "sparse_polynomial_formula": (formula, formula_grid),
    "spline_additive_formula": (spline, spline_grid),
    "single_rule_tree": (plain_tree, plain_tree_grid),
    "linear_leaf_model_tree": (model_tree, model_tree_grid),
    "boosted_rule_ensemble": (boosted_rules, boosted_rules_grid),
}

rows = []
pred_table = pd.DataFrame({"patient_id": ids, "teacher_probability": y})
all_params = {}
for name, (est, grid) in specs.items():
    p, params = nested_oof(est, grid, X, y)
    pred_table[name] = p
    row = {"model": name, **metrics(y, p)}
    rows.append(row)
    all_params[name] = params
    print(name, row, flush=True)

metrics_df = pd.DataFrame(rows).sort_values("r2", ascending=False)
metrics_df.to_csv(OUT / "HONEST_NESTED_OOF_METRICS.csv", index=False)
pred_table.to_csv(OUT / "HONEST_NESTED_OOF_PREDICTIONS.csv", index=False)
(OUT / "INNER_SELECTED_PARAMETERS.json").write_text(json.dumps(all_params, indent=2), encoding="utf-8")

# Fit final descriptive artifacts using the modal/most frequent nested choice.
for name, (est, grid) in specs.items():
    encoded = [json.dumps(p, sort_keys=True) for p in all_params[name]]
    best = json.loads(max(set(encoded), key=encoded.count))
    final = clone(est).set_params(**best).fit(X, y)
    joblib.dump(final, OUT / f"{name}.joblib")
    (OUT / f"{name}_final_params.json").write_text(json.dumps(best, indent=2), encoding="utf-8")

    if name == "single_rule_tree":
        selected = final.named_steps["select"].get_support()
        names = feature_names[selected]
        rules = export_text(final.named_steps["tree"], feature_names=list(names), decimals=5)
        (OUT / "SINGLE_RULE_TREE.txt").write_text(rules, encoding="utf-8")

summary = {
    "validation": "five-fold outer CV with four-fold inner model selection; all feature selection performed inside training folds",
    "target": "locked teacher probability",
    "n_patients": int(len(y)),
    "warning": "Report only nested OOF metrics. Final full-data artifacts are descriptive/deployment fits, not independent performance estimates.",
    "results": rows,
}
(OUT / "SUMMARY.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

"""Validated inference examples for the final distillation analysis."""

import joblib
import numpy as np


def final_high_fidelity_probability(neural_probability, concept_probability):
    """Fixed blend evaluated by outer-fold predictions; R2 = 0.775790."""
    return np.clip(0.70 * neural_probability + 0.30 * concept_probability, 0.0, 1.0)


def ebm_probability(feature_matrix, model_path="explainable_boosting_machine.joblib"):
    """Exact additive glass-box prediction; nested OOF R2 = 0.677685."""
    model = joblib.load(model_path)
    return np.clip(model.predict(feature_matrix), 0.0, 1.0)


def linear_leaf_probability(feature_matrix, model_path="linear_leaf_model_tree.joblib"):
    """One-split model tree with explicit linear leaf equations; nested OOF R2 = 0.549993."""
    model = joblib.load(model_path)
    return np.clip(model.predict(feature_matrix), 0.0, 1.0)

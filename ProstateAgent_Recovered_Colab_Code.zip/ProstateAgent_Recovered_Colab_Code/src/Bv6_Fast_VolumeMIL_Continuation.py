
# B-v6 Fast Volume-MIL — same Colab runtime after B-v5
# IMPORTANT:
# - Frozen B-v3 + frozen DINOv2.
# - Train ONLY a small volume-MIL head.
# - Uses prior UCLA B-v4/B-v5 patients as DEVELOPMENT data.
# - Locks a NEW 200-patient UCLA test set before training.
# - Therefore the new UCLA set is a patient-held-out SAME-COLLECTION test,
#   NOT the final independent external cohort for the paper.

import os, re, gc, json, math, time, random, hashlib, shutil, zipfile, subprocess, sys, warnings
from pathlib import Path
from contextlib import nullcontext

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader, WeightedRandomSampler
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score, average_precision_score
import SimpleITK as sitk

warnings.filterwarnings("ignore")
SEED=20260913
random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
if torch.cuda.is_available(): torch.cuda.manual_seed_all(SEED)

# -----------------------------
# 0) REQUIRE CURRENT STATE
# -----------------------------
required = ["bv3","bv3proc","dino","DINO_TF","DEVICE","volume_to_bag","read_dicom_volume"]
missing=[x for x in required if x not in globals()]
if missing:
    raise RuntimeError(
        "Keep the SAME runtime. Missing: "+", ".join(missing)+
        ". Re-run the successful B-v5 setup/model cells only."
    )

try:
    from idc_index import IDCClient
except Exception:
    subprocess.run([sys.executable,"-m","pip","install","-q","idc-index"],check=True)
    from idc_index import IDCClient

ROOT=Path("/content/Bv6_Fast_VolumeMIL")
RES=ROOT/"results"
NEW_DIR=ROOT/"ucla_new_test_dicom"
for p in [ROOT,RES,NEW_DIR]:
    p.mkdir(parents=True,exist_ok=True)

# -----------------------------
# 1) FIND PRIOR UCLA DEVELOPMENT FILES
# -----------------------------
V4_FINAL=Path("/content/Bv4_Lite_DomainNull/results/BV4_UCLA_FINAL_PREDICTIONS_WITH_PATHOLOGY.csv")
V5_FINAL=Path("/content/Bv5_VolumeMIL/results/BV5_UCLA_FINAL_WITH_PATHOLOGY.csv")
V4_LOCK=Path("/content/Bv4_Lite_DomainNull/results/BV4_UCLA_DISJOINT_HOLDOUT_PRETRAIN.csv")
V5_LOCK=Path("/content/Bv5_VolumeMIL/results/BV5_NEW_UCLA_HOLDOUT_PRETRAIN.csv")
V4_DICOM=Path("/content/Bv4_Lite_DomainNull/ucla_holdout_dicom")
V5_DICOM=Path("/content/Bv5_VolumeMIL/ucla_new_holdout")
OLD300_ZIP=Path("/content/Prostate_T2_Agent_B_v3_UCLA_FINAL_EXTERNAL_RESULTS.zip")
BIOPSY_XLSX=Path("/content/Bv5_VolumeMIL/TCIA_Biopsy_Data_2020-07-14.xlsx")
if not BIOPSY_XLSX.exists():
    BIOPSY_XLSX=Path("/content/Bv4_Lite_DomainNull/tmp/TCIA_Biopsy_Data_2020-07-14.xlsx")

for p in [V4_FINAL,V5_FINAL,V4_LOCK,V5_LOCK,OLD300_ZIP,BIOPSY_XLSX]:
    if not p.exists():
        raise FileNotFoundError(f"Missing prior file in current runtime: {p}")

v4=pd.read_csv(V4_FINAL)
v5=pd.read_csv(V5_FINAL)
for d,name in [(v4,"B-v4"),(v5,"B-v5")]:
    for c in ["patient_key","mr_uid","any_cancer"]:
        if c not in d.columns:
            raise RuntimeError(f"{name} file missing column {c}")

v4["dev_source"]="UCLA_v4"; v4["dicom_root"]=str(V4_DICOM)
v5["dev_source"]="UCLA_v5"; v5["dicom_root"]=str(V5_DICOM)
ucla_dev=pd.concat([
    v4[["patient_key","mr_uid","any_cancer","dev_source","dicom_root"]],
    v5[["patient_key","mr_uid","any_cancer","dev_source","dicom_root"]],
],ignore_index=True).drop_duplicates("patient_key")

print("Prior UCLA development patients:",len(ucla_dev))
print("Cancer counts:",ucla_dev.any_cancer.value_counts().sort_index().to_dict())

# -----------------------------
# 2) LOCK FRESH UCLA TEST BEFORE TRAINING
# -----------------------------
with zipfile.ZipFile(OLD300_ZIP) as z:
    nm=next(n for n in z.namelist() if n.endswith("UCLA_FINAL_EXTERNAL_COHORT_PRELABEL.csv"))
    old300=pd.read_csv(z.open(nm))
old_ids=set(old300.patient_key.astype(str).str.strip())
old_ids |= set(pd.read_csv(V4_LOCK).patient_key.astype(str).str.strip())
old_ids |= set(pd.read_csv(V5_LOCK).patient_key.astype(str).str.strip())
print("Previously used UCLA patients excluded:",len(old_ids))

meta=pd.read_excel(
    BIOPSY_XLSX,sheet_name=0,
    usecols=["Patient Number","Series Instance UID (MRI)"],
    engine="openpyxl"
).rename(columns={"Patient Number":"patient_key","Series Instance UID (MRI)":"mr_uid"})
meta=meta.dropna(subset=["patient_key","mr_uid"]).copy()
meta["patient_key"]=meta.patient_key.astype(str).str.strip()
meta["mr_uid"]=meta.mr_uid.astype(str).str.strip()

counts=(meta.groupby(["patient_key","mr_uid"]).size().rename("n_cores").reset_index())
counts=(counts[counts.n_cores>=6]
        .sort_values(["patient_key","n_cores","mr_uid"],ascending=[True,False,True])
        .drop_duplicates("patient_key",keep="first"))

client=IDCClient.client()
idc=client.sql_query("""
SELECT PatientID, SeriesInstanceUID, SeriesDescription, series_size_MB
FROM index
WHERE collection_id='prostate_mri_us_biopsy' AND Modality='MR'
""")
idc["SeriesInstanceUID"]=idc.SeriesInstanceUID.astype(str).str.strip()
idc=idc.drop_duplicates("SeriesInstanceUID")

eligible=counts.merge(idc.rename(columns={"SeriesInstanceUID":"mr_uid"}),on="mr_uid",how="inner")
desc=eligible.SeriesDescription.fillna("").astype(str).str.lower()
eligible=eligible[
    desc.str.contains("t2",regex=False) &
    ~desc.str.contains(r"\badc\b|\bdwi\b|diffusion|trace|localizer",regex=True)
].copy()
eligible=eligible[~eligible.patient_key.astype(str).isin(old_ids)].copy()

SALT="BV6_FRESH_UCLA_TEST_20260913"
eligible["selection_hash"]=[
    hashlib.sha256(f"{SALT}|{p}|{u}".encode()).hexdigest()
    for p,u in zip(eligible.patient_key,eligible.mr_uid)
]
eligible=eligible.sort_values("selection_hash").reset_index(drop=True)

TARGET=min(200,len(eligible))
if TARGET<120:
    raise RuntimeError(f"Only {TARGET} fresh UCLA patients remain; too few for this check.")
NEW_TEST=eligible.head(TARGET).copy()

lock=RES/"BV6_FRESH_UCLA_TEST_PRETRAIN.csv"
NEW_TEST.to_csv(lock,index=False)
lock_sha=hashlib.sha256(lock.read_bytes()).hexdigest()
json.dump({
    "n":int(TARGET),
    "labels_accessed":False,
    "locked_before_training":True,
    "patient_disjoint_from_prior_ucla":True,
    "sha256":lock_sha,
    "note":"same-collection patient-held-out test; not final independent external"
},open(RES/"BV6_TEST_LOCK.json","w"),indent=2)

print("✅ Fresh UCLA test locked BEFORE training:",TARGET)
print("SHA256:",lock_sha)

# -----------------------------
# 3) ENSURE PRIOR UCLA DEV DICOMs EXIST
# -----------------------------
def has_series(root,uid):
    d=Path(root)/str(uid)
    return d.exists() and any(p.is_file() for p in d.rglob("*"))

def dl_series(uids,root,source="aws"):
    client.download_dicom_series(
        seriesInstanceUID=list(uids),
        downloadDir=str(root),
        quiet=False,
        show_progress_bar=True,
        use_s5cmd_sync=True,
        dirTemplate="%SeriesInstanceUID",
        source_bucket_location=source
    )

for root in [V4_DICOM,V5_DICOM]:
    root.mkdir(parents=True,exist_ok=True)

for source_df,root in [(v4,V4_DICOM),(v5,V5_DICOM)]:
    need=[str(u) for u in source_df.mr_uid.astype(str) if not has_series(root,u)]
    if need:
        print("Redownloading missing development series:",len(need))
        for s in range(0,len(need),20):
            batch=need[s:s+20]
            try: dl_series(batch,root,"aws")
            except Exception:
                dl_series(batch,root,"gcs")

# -----------------------------
# 4) BUILD/CACHE UCLA DEV VOLUME BAGS
# -----------------------------
CACHE=ROOT/"UCLA_DEV_BAGS.npz"
CACHE_META=ROOT/"UCLA_DEV_META.csv"

if CACHE.exists() and CACHE_META.exists():
    zz=np.load(CACHE)
    X_UCLA=zz["bags"].astype(np.float32)
    Y_UCLA=zz["y"].astype(int)
    umeta=pd.read_csv(CACHE_META)
    print("Loaded cached UCLA dev bags:",X_UCLA.shape)
else:
    bags=[]; ys=[]; rows=[]
    for i,r in ucla_dev.reset_index(drop=True).iterrows():
        d=Path(r.dicom_root)/str(r.mr_uid)
        try:
            vol=read_dicom_volume(d)
            bag=volume_to_bag(vol).astype(np.float32)
            bags.append(bag); ys.append(int(r.any_cancer))
            rows.append({
                "patient_key":str(r.patient_key),"mr_uid":str(r.mr_uid),
                "label":int(r.any_cancer),"source":r.dev_source
            })
        except Exception as e:
            print("skip dev",r.patient_key,repr(e)[:100])
        if len(bags)>0 and len(bags)%20==0:
            print("UCLA dev bags:",len(bags))
            if DEVICE=="cuda": torch.cuda.empty_cache()
    X_UCLA=np.stack(bags).astype(np.float32)
    Y_UCLA=np.asarray(ys,int)
    umeta=pd.DataFrame(rows)
    np.savez_compressed(CACHE,bags=X_UCLA,y=Y_UCLA)
    umeta.to_csv(CACHE_META,index=False)

print("UCLA dev:",X_UCLA.shape,dict(zip(*np.unique(Y_UCLA,return_counts=True))))
if len(X_UCLA)<300 or len(np.unique(Y_UCLA))<2:
    raise RuntimeError("Too few UCLA development bags.")

# -----------------------------
# 5) LOAD P158 BAGS FROM B-v5 CACHE
# -----------------------------
P158_CACHE=Path("/content/Bv5_VolumeMIL/P158_BAGS.npz")
P158_META=Path("/content/Bv5_VolumeMIL/P158_META.csv")
if not P158_CACHE.exists() or not P158_META.exists():
    raise FileNotFoundError("B-v5 P158 cache missing; do not redownload—rerun B-v5 feature step only.")
zz=np.load(P158_CACHE)
X_P158=zz["bags"].astype(np.float32)
pm=pd.read_csv(P158_META)
Y_P158=pm.label.to_numpy(int)
print("P158 dev:",X_P158.shape,dict(zip(*np.unique(Y_P158,return_counts=True))))

# -----------------------------
# 6) COMBINE SOURCES
# -----------------------------
X=np.concatenate([X_UCLA,X_P158],axis=0)
Y=np.concatenate([Y_UCLA,Y_P158],axis=0)
SRC=np.concatenate([
    np.zeros(len(X_UCLA),int),  # UCLA
    np.ones(len(X_P158),int),   # P158
])

# stratify by source+label
strata=SRC*2+Y
print("Combined development:",X.shape)
print("Source x label:",pd.Series(strata).value_counts().sort_index().to_dict())

# -----------------------------
# 7) ROBUST TINY MIL HEAD
# -----------------------------
class RobustMIL(nn.Module):
    def __init__(self,d=384,h=128):
        super().__init__()
        self.norm=nn.LayerNorm(d)
        self.proj=nn.Sequential(
            nn.Linear(d,h), nn.GELU(), nn.Dropout(0.20),
            nn.LayerNorm(h)
        )
        self.gate_v=nn.Linear(h,64)
        self.gate_u=nn.Linear(h,64)
        self.attn=nn.Linear(64,1)
        self.cls=nn.Sequential(
            nn.Linear(h*3,128), nn.GELU(), nn.Dropout(0.25),
            nn.Linear(128,1)
        )
    def forward(self,x):
        h=self.proj(self.norm(x))
        a=torch.tanh(self.gate_v(h))*torch.sigmoid(self.gate_u(h))
        a=torch.softmax(self.attn(a).squeeze(-1),dim=1)
        att=(h*a.unsqueeze(-1)).sum(1)
        mean=h.mean(1)
        mx=h.max(1).values
        logit=self.cls(torch.cat([att,mean,mx],dim=1)).squeeze(-1)
        return logit,a

Xt=torch.tensor(X,dtype=torch.float32)
Yt=torch.tensor(Y,dtype=torch.float32)

cv=StratifiedKFold(5,shuffle=True,random_state=SEED)
oof=np.zeros(len(Y),float)
fold_states=[]

def sample_weights(indices):
    # equalize each source x class group during training
    ss=SRC[indices]; yy=Y[indices]
    keys=ss*2+yy
    counts=pd.Series(keys).value_counts().to_dict()
    w=np.array([1.0/counts[int(k)] for k in keys],float)
    w=w/w.mean()
    return torch.tensor(w,dtype=torch.double)

def train_fold(tr,va,fold):
    m=RobustMIL(d=X.shape[-1]).to(DEVICE)
    sampler=WeightedRandomSampler(sample_weights(tr),num_samples=len(tr),replacement=True)
    dl=DataLoader(TensorDataset(Xt[tr],Yt[tr]),batch_size=20,sampler=sampler)
    opt=torch.optim.AdamW(m.parameters(),lr=7e-4,weight_decay=3e-4)
    lossfn=nn.BCEWithLogitsLoss()
    best=None; best_auc=-1; patience=0
    for epoch in range(70):
        m.train()
        for xb,yb in dl:
            xb=xb.to(DEVICE); yb=yb.to(DEVICE)
            opt.zero_grad(set_to_none=True)
            logit,_=m(xb)
            loss=lossfn(logit,yb)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(m.parameters(),5.0)
            opt.step()
        m.eval()
        with torch.no_grad():
            pv=torch.sigmoid(m(Xt[va].to(DEVICE))[0]).cpu().numpy()
        auc=roc_auc_score(Y[va],pv)
        if auc>best_auc+1e-4:
            best_auc=auc
            best={k:v.detach().cpu().clone() for k,v in m.state_dict().items()}
            patience=0
        else:
            patience+=1
        if patience>=10: break
    m.load_state_dict(best); m.eval()
    with torch.no_grad():
        pv=torch.sigmoid(m(Xt[va].to(DEVICE))[0]).cpu().numpy()
    print(f"Fold {fold}: AUC={roc_auc_score(Y[va],pv):.3f}")
    return best,pv

for fold,(tr,va) in enumerate(cv.split(X,strata)):
    st,p=train_fold(tr,va,fold)
    fold_states.append(st); oof[va]=p
    if DEVICE=="cuda": torch.cuda.empty_cache()

oof_all=roc_auc_score(Y,oof)
oof_ucla=roc_auc_score(Y[SRC==0],oof[SRC==0])
oof_p158=roc_auc_score(Y[SRC==1],oof[SRC==1])
print("\n✅ B-v6 development OOF")
print("Overall:",round(oof_all,3)," UCLA:",round(oof_ucla,3)," P158:",round(oof_p158,3))

torch.save({
    "fold_states":fold_states,
    "d":int(X.shape[-1]),
    "oof_auc_all":float(oof_all),
    "oof_auc_ucla":float(oof_ucla),
    "oof_auc_p158":float(oof_p158),
},RES/"BV6_ROBUST_MIL_HEADS.pt")

# -----------------------------
# 8) DOWNLOAD FRESH TEST DICOMs
# -----------------------------
uids=NEW_TEST.mr_uid.astype(str).tolist()
for s in range(0,len(uids),20):
    need=[u for u in uids[s:s+20] if not has_series(NEW_DIR,u)]
    if not need: continue
    print("Fresh UCLA download",s+1,"-",min(s+20,len(uids)))
    try: dl_series(need,NEW_DIR,"aws")
    except Exception:
        try: dl_series(need,NEW_DIR,"gcs")
        except Exception:
            for u in need:
                try: dl_series([u],NEW_DIR,"aws")
                except Exception:
                    try: dl_series([u],NEW_DIR,"gcs")
                    except Exception: pass

# -----------------------------
# 9) PREDICT BEFORE LABELS
# -----------------------------
models=[]
for st in fold_states:
    m=RobustMIL(d=X.shape[-1]).to(DEVICE)
    m.load_state_dict(st); m.eval()
    models.append(m)

@torch.inference_mode()
def bv6_prob(bag):
    xx=torch.tensor(bag[None,...],dtype=torch.float32,device=DEVICE)
    ps=[torch.sigmoid(m(xx)[0]).item() for m in models]
    return float(np.mean(ps))

rows=[]; fails=[]
for i,r in NEW_TEST.iterrows():
    uid=str(r.mr_uid)
    d=NEW_DIR/uid
    if not has_series(NEW_DIR,uid):
        fails.append({"patient_key":r.patient_key,"mr_uid":uid,"error":"download_missing"})
        continue
    try:
        vol=read_dicom_volume(d)
        bag=volume_to_bag(vol)
        p6=bv6_prob(bag)
        p3=float(bv3.predict(vol)[0])
        rows.append({
            "patient_key":str(r.patient_key),
            "mr_uid":uid,
            "locked_bv3_probability":p3,
            "bv6_volume_mil_probability":p6
        })
    except Exception as e:
        fails.append({"patient_key":r.patient_key,"mr_uid":uid,"error":repr(e)})
    if (i+1)%10==0:
        print("Fresh test inference:",i+1,"/",len(NEW_TEST))
        if DEVICE=="cuda": torch.cuda.empty_cache()

pred=pd.DataFrame(rows)
pd.DataFrame(fails).to_csv(RES/"BV6_TECHNICAL_FAILURES.csv",index=False)
if len(pred)<max(100,int(.85*TARGET)):
    raise RuntimeError(f"Only {len(pred)} fresh test predictions succeeded.")

pred_file=RES/"BV6_FRESH_UCLA_PREDICTIONS_BEFORE_PATHOLOGY.csv"
pred.to_csv(pred_file,index=False)
pred_sha=hashlib.sha256(pred_file.read_bytes()).hexdigest()
json.dump({
    "n":int(len(pred)),
    "sealed_before_pathology":True,
    "sha256":pred_sha,
    "test_lock_sha256":lock_sha
},open(RES/"BV6_PRELABEL_PREDICTION_LOCK.json","w"),indent=2)
print("✅ Predictions sealed BEFORE pathology")

# -----------------------------
# 10) NOW READ PATHOLOGY
# -----------------------------
lab=pd.read_excel(
    BIOPSY_XLSX,sheet_name=0,
    usecols=["Patient Number","Series Instance UID (MRI)","Primary Gleason","Secondary Gleason"],
    engine="openpyxl"
).rename(columns={
    "Patient Number":"patient_key",
    "Series Instance UID (MRI)":"mr_uid",
    "Primary Gleason":"g1_raw",
    "Secondary Gleason":"g2_raw"
})
lab=lab.dropna(subset=["patient_key","mr_uid"]).copy()
lab["patient_key"]=lab.patient_key.astype(str).str.strip()
lab["mr_uid"]=lab.mr_uid.astype(str).str.strip()
pairs=set(zip(pred.patient_key,pred.mr_uid))
lab=lab[lab.apply(lambda r:(r.patient_key,r.mr_uid) in pairs,axis=1)].copy()

def num(x):
    if pd.isna(x): return np.nan
    if isinstance(x,(int,float,np.integer,np.floating)): return float(x)
    s=str(x).strip().lower()
    if s in {"","nan","none","na","n/a","benign","negative"}: return np.nan
    m=re.search(r"([1-5])",s)
    return float(m.group(1)) if m else np.nan

lab["g1"]=lab.g1_raw.map(num); lab["g2"]=lab.g2_raw.map(num)
lab["cancer_core"]=((lab.g1.notna())|(lab.g2.notna())).astype(int)
lab["gs"]=lab[["g1","g2"]].sum(axis=1,min_count=2)
lab["cspca_core"]=(lab.gs>=7).fillna(False).astype(int)
agg=(lab.groupby(["patient_key","mr_uid"])
     .agg(any_cancer=("cancer_core","max"),
          any_cspca=("cspca_core","max"),
          max_gleason=("gs","max"))
     .reset_index())

final=pred.merge(agg,on=["patient_key","mr_uid"],how="inner",validate="one_to_one")

def auc_ci(y,p,B=3000):
    y=np.asarray(y,int); p=np.asarray(p,float)
    rng=np.random.default_rng(SEED); vals=[]
    for _ in range(B):
        ix=rng.integers(0,len(y),len(y))
        if len(np.unique(y[ix]))<2: continue
        vals.append(roc_auc_score(y[ix],p[ix]))
    return [float(np.percentile(vals,2.5)),float(np.percentile(vals,97.5))]

report={}
for ep in ["any_cancer","any_cspca"]:
    report[ep]={}
    for name,col in [
        ("locked_bv3","locked_bv3_probability"),
        ("bv6_volume_mil","bv6_volume_mil_probability"),
    ]:
        y=final[ep].to_numpy(int); p=final[col].to_numpy(float)
        report[ep][name]={
            "n":int(len(y)),
            "roc_auc":float(roc_auc_score(y,p)),
            "roc_auc_ci95":auc_ci(y,p),
            "pr_auc":float(average_precision_score(y,p))
        }

final.to_csv(RES/"BV6_FRESH_UCLA_FINAL_WITH_PATHOLOGY.csv",index=False)
json.dump(report,open(RES/"BV6_FRESH_UCLA_FINAL_METRICS.json","w"),indent=2)

print("\n"+"="*72)
print("B-v6 FRESH UCLA PATIENT-HELD-OUT TEST")
print("NOTE: SAME UCLA COLLECTION; NOT FINAL INDEPENDENT EXTERNAL")
print("N =",len(final))
for ep,title in [("any_cancer","ANY CANCER"),("any_cspca","csPCa GS>=7")]:
    print("\n"+title)
    for k,v in report[ep].items():
        lo,hi=v["roc_auc_ci95"]
        print(f"{k:18s} AUC={v['roc_auc']:.3f}  CI={lo:.3f}-{hi:.3f}")
print("="*72)

EXPORT=Path("/content/Prostate_T2_Agent_B_v6_Fast_FINAL_RESULTS")
shutil.rmtree(EXPORT,ignore_errors=True)
shutil.copytree(RES,EXPORT)
zip_path=shutil.make_archive(str(EXPORT),"zip",EXPORT)
print("\n✅ COMPLETE")
print(zip_path)
try:
    from google.colab import files
    files.download(zip_path)
except Exception:
    pass

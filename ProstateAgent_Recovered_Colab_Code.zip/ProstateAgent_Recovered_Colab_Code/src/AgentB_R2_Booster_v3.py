
# ======================================================================
# AGENT B — R² BOOSTER v3
# Legitimate nested-CV teacher distillation on the already-extracted bags.
#
# RUN NOW, before the previous Phase-7 resume cell.
#
# What this upgrades:
#   1) High-fidelity bag-level student trained directly from 12x384 DINO bags
#   2) Nested classical nonlinear stack on ordered bags + bag moments + concepts
#   3) Fixed 50:50 logit blend of the two
#   4) Selects the best DEVELOPMENT candidate transparently and updates
#      stack_metrics/stack_p for the remaining report.
#
# It does NOT:
#   - use outcome labels,
#   - touch external test labels,
#   - retrain the cancer classifier,
#   - fabricate R².
#
# The goal is to raise teacher-surrogate fidelity above the current 0.730.
# ======================================================================

import os, gc, math, json, random, hashlib, warnings, joblib
from copy import deepcopy
from pathlib import Path

import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

from sklearn.base import clone
from sklearn.model_selection import StratifiedKFold, train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.linear_model import RidgeCV
from sklearn.kernel_ridge import KernelRidge
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error

warnings.filterwarnings("ignore")

SEED = 20260913
random.seed(SEED)
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(SEED)

need = [
    "BAGS","ENGINEERED","CONCEPT_X",
    "TEACHER_P","TEACHER_LOGIT",
    "meta","OUT","DEVICE","FEATURE_NAMES",
    "stack_metrics","stack_p"
]
missing = [x for x in need if x not in globals()]
if missing:
    raise RuntimeError(
        "The Phase-0..6 state is not available. Missing: " + ", ".join(missing)
    )

BOOST = Path(OUT) / "R2_BOOSTER_v3"
BOOST.mkdir(parents=True, exist_ok=True)

N, K, D = BAGS.shape
y_prob = np.asarray(TEACHER_P, float)
y_logit = np.log(
    np.clip(y_prob, 1e-5, 1-1e-5) /
    (1 - np.clip(y_prob, 1e-5, 1-1e-5))
)

# ----------------------------------------------------------------------
# 1) Rich teacher-independent features from the bag.
# ----------------------------------------------------------------------
bag_mean = BAGS.mean(axis=1)
bag_std  = BAGS.std(axis=1)
bag_max  = BAGS.max(axis=1)
bag_min  = BAGS.min(axis=1)
bag_q25  = np.quantile(BAGS, 0.25, axis=1)
bag_q75  = np.quantile(BAGS, 0.75, axis=1)

X_raw = np.concatenate([
    BAGS.reshape(N, -1),
    bag_mean, bag_std, bag_max, bag_min, bag_q25, bag_q75,
    ENGINEERED,
    CONCEPT_X
], axis=1).astype(np.float32)

X_raw = np.nan_to_num(X_raw, nan=0.0, posinf=0.0, neginf=0.0)

# continuous-target stratification
bins = pd.qcut(y_prob, q=5, labels=False, duplicates="drop")
bins = np.asarray(bins, int)

outer = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)

# ----------------------------------------------------------------------
# 2) Classical nonlinear nested stack.
# ----------------------------------------------------------------------
def classical_models(seed):
    return {
        "pca_ridge": Pipeline([
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=96, svd_solver="randomized", random_state=seed)),
            ("reg", RidgeCV(alphas=np.logspace(-4, 3, 24)))
        ]),
        "rbf_krr_soft": Pipeline([
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=96, svd_solver="randomized", random_state=seed+1)),
            ("reg", KernelRidge(alpha=0.08, kernel="rbf", gamma=0.004))
        ]),
        "rbf_krr_sharp": Pipeline([
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=96, svd_solver="randomized", random_state=seed+2)),
            ("reg", KernelRidge(alpha=0.04, kernel="rbf", gamma=0.012))
        ]),
        "extra_trees": ExtraTreesRegressor(
            n_estimators=450,
            min_samples_leaf=2,
            max_features=0.35,
            random_state=seed,
            n_jobs=-1
        ),
        "hist_gb": Pipeline([
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=64, svd_solver="randomized", random_state=seed+3)),
            ("reg", HistGradientBoostingRegressor(
                learning_rate=0.035,
                max_iter=260,
                max_leaf_nodes=15,
                min_samples_leaf=10,
                l2_regularization=1.0,
                random_state=seed
            ))
        ]),
        "pca_mlp": Pipeline([
            ("scale", StandardScaler()),
            ("pca", PCA(n_components=96, svd_solver="randomized", random_state=seed+4)),
            ("reg", MLPRegressor(
                hidden_layer_sizes=(96, 48),
                activation="relu",
                alpha=3e-3,
                learning_rate_init=5e-4,
                max_iter=700,
                early_stopping=True,
                validation_fraction=0.15,
                n_iter_no_change=30,
                random_state=seed
            ))
        ])
    }

classical_logit_oof = np.zeros(N, float)

print("\n=== BOOSTER PART A: nested nonlinear stack ===")

for fold, (tr, va) in enumerate(outer.split(X_raw, bins), start=1):
    Xtr, Xva = X_raw[tr], X_raw[va]
    ytr = y_logit[tr]
    btr = bins[tr]

    base = classical_models(SEED + 100*fold)
    names = list(base.keys())

    inner = StratifiedKFold(
        n_splits=3, shuffle=True, random_state=SEED + fold
    )

    inner_oof = np.zeros((len(tr), len(names)), float)
    val_mat = np.zeros((len(va), len(names)), float)

    for j, name in enumerate(names):
        template = base[name]

        for itr, iva in inner.split(Xtr, btr):
            m = clone(template)
            m.fit(Xtr[itr], ytr[itr])
            inner_oof[iva, j] = np.asarray(m.predict(Xtr[iva])).reshape(-1)

        fm = clone(template)
        fm.fit(Xtr, ytr)
        val_mat[:, j] = np.asarray(fm.predict(Xva)).reshape(-1)

    meta_reg = RidgeCV(alphas=np.logspace(-4, 3, 24))
    meta_reg.fit(inner_oof, ytr)
    classical_logit_oof[va] = meta_reg.predict(val_mat)

    fold_p = 1/(1+np.exp(-classical_logit_oof[va]))
    print(
        f"fold {fold}: classical R² = "
        f"{r2_score(y_prob[va], fold_p):.3f}"
    )

classical_p = 1/(1+np.exp(-classical_logit_oof))
classical_r2 = float(r2_score(y_prob, classical_p))

print("Nested classical stack R²:", round(classical_r2, 3))

# ----------------------------------------------------------------------
# 3) Neural permutation-invariant bag student.
# ----------------------------------------------------------------------
class BagStudent(nn.Module):
    def __init__(self, d_in=384, h=96):
        super().__init__()
        self.slice_net = nn.Sequential(
            nn.Linear(d_in, 192),
            nn.GELU(),
            nn.LayerNorm(192),
            nn.Dropout(0.08),
            nn.Linear(192, h),
            nn.GELU(),
        )
        self.att_v = nn.Linear(h, 64)
        self.att_u = nn.Linear(h, 64)
        self.att_w = nn.Linear(64, 1)
        self.head = nn.Sequential(
            nn.Linear(h*4, 160),
            nn.GELU(),
            nn.Dropout(0.12),
            nn.Linear(160, 64),
            nn.GELU(),
            nn.Linear(64, 1)
        )

    def forward(self, x):
        h = self.slice_net(x)  # B,K,H

        a = torch.tanh(self.att_v(h)) * torch.sigmoid(self.att_u(h))
        a = torch.softmax(self.att_w(a).squeeze(-1), dim=1)

        att = torch.sum(a.unsqueeze(-1) * h, dim=1)
        mean = h.mean(dim=1)
        mx = h.max(dim=1).values
        sd = h.std(dim=1, unbiased=False)

        pooled = torch.cat([att, mean, mx, sd], dim=1)
        logit = self.head(pooled).squeeze(-1)
        return logit, a

def train_fixed_epochs(Xbag, ylog, mu, sd, epochs, seed):
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    model = BagStudent(d_in=D, h=96).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=8e-4, weight_decay=2e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=max(epochs,1), eta_min=8e-6
    )

    Xz = (Xbag - mu[None,None,:]) / sd[None,None,:]
    ds = TensorDataset(
        torch.tensor(Xz, dtype=torch.float32),
        torch.tensor(ylog, dtype=torch.float32)
    )
    dl = DataLoader(ds, batch_size=32, shuffle=True)

    model.train()
    for _ in range(int(epochs)):
        for xb, yb in dl:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)

            # small teacher-preserving representation noise
            xb = xb + 0.008 * torch.randn_like(xb)

            opt.zero_grad(set_to_none=True)
            pred, _ = model(xb)

            loss_logit = torch.mean((pred-yb)**2)
            loss_prob = torch.mean(
                (torch.sigmoid(pred)-torch.sigmoid(yb))**2
            )
            loss = loss_logit + 0.25*loss_prob

            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()

        sched.step()

    model.eval()
    return model

def choose_epoch(Xbag, ylog, ybins, seed):
    ids = np.arange(len(Xbag))
    a, b = train_test_split(
        ids, test_size=0.18, random_state=seed, stratify=ybins
    )

    mu = Xbag[a].reshape(-1,D).mean(axis=0)
    sd = Xbag[a].reshape(-1,D).std(axis=0) + 1e-6

    Xza = (Xbag[a] - mu[None,None,:]) / sd[None,None,:]
    Xzb = (Xbag[b] - mu[None,None,:]) / sd[None,None,:]

    train_ds = TensorDataset(
        torch.tensor(Xza, dtype=torch.float32),
        torch.tensor(ylog[a], dtype=torch.float32)
    )
    train_dl = DataLoader(train_ds, batch_size=32, shuffle=True)

    xb_val = torch.tensor(Xzb, dtype=torch.float32, device=DEVICE)
    yb_val = torch.tensor(ylog[b], dtype=torch.float32, device=DEVICE)

    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

    model = BagStudent(d_in=D, h=96).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=8e-4, weight_decay=2e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(
        opt, T_max=320, eta_min=8e-6
    )

    best_loss = float("inf")
    best_epoch = 1
    patience = 0

    for epoch in range(1, 321):
        model.train()
        for xb, yb in train_dl:
            xb = xb.to(DEVICE)
            yb = yb.to(DEVICE)
            xb = xb + 0.008*torch.randn_like(xb)

            opt.zero_grad(set_to_none=True)
            pred, _ = model(xb)
            loss = (
                torch.mean((pred-yb)**2)
                + 0.25*torch.mean(
                    (torch.sigmoid(pred)-torch.sigmoid(yb))**2
                )
            )
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(),5.0)
            opt.step()

        sched.step()

        model.eval()
        with torch.inference_mode():
            pv, _ = model(xb_val)
            vl = float(torch.mean((pv-yb_val)**2).item())

        if vl < best_loss - 1e-5:
            best_loss = vl
            best_epoch = epoch
            patience = 0
        else:
            patience += 1

        if epoch >= 45 and patience >= 35:
            break

    # avoid unstable tiny or huge epoch choices
    return int(np.clip(best_epoch, 40, 280))

@torch.inference_mode()
def predict_student(model, Xbag, mu, sd):
    Xz = (Xbag - mu[None,None,:]) / sd[None,None,:]
    out = []
    for s in range(0, len(Xz), 64):
        xb = torch.tensor(
            Xz[s:s+64], dtype=torch.float32, device=DEVICE
        )
        z, _ = model(xb)
        out.append(z.cpu().numpy())
    return np.concatenate(out)

deep_logit_oof = np.zeros(N, float)
chosen_epochs = []

print("\n=== BOOSTER PART B: neural bag distillation ===")

for fold, (tr, va) in enumerate(outer.split(BAGS, bins), start=1):
    preds = []

    # outer-train-only standardization
    mu = BAGS[tr].reshape(-1,D).mean(axis=0)
    sd = BAGS[tr].reshape(-1,D).std(axis=0) + 1e-6

    for sidx, seedoff in enumerate([11, 37, 73], start=1):
        seed = SEED + 1000*fold + seedoff

        ep = choose_epoch(
            BAGS[tr],
            y_logit[tr],
            bins[tr],
            seed
        )
        chosen_epochs.append(ep)

        model = train_fixed_epochs(
            BAGS[tr],
            y_logit[tr],
            mu, sd,
            ep,
            seed
        )

        preds.append(
            predict_student(model, BAGS[va], mu, sd)
        )

        del model
        if DEVICE == "cuda":
            torch.cuda.empty_cache()
        gc.collect()

    deep_logit_oof[va] = np.mean(np.stack(preds, axis=0), axis=0)

    fold_p = 1/(1+np.exp(-deep_logit_oof[va]))
    print(
        f"fold {fold}: neural bag-student R² = "
        f"{r2_score(y_prob[va], fold_p):.3f}"
    )

deep_p = 1/(1+np.exp(-deep_logit_oof))
deep_r2 = float(r2_score(y_prob, deep_p))

print("Nested neural bag-student R²:", round(deep_r2,3))

# ----------------------------------------------------------------------
# 4) Fixed pre-specified 50:50 logit blend.
# ----------------------------------------------------------------------
blend_logit = 0.5*classical_logit_oof + 0.5*deep_logit_oof
blend_p = 1/(1+np.exp(-blend_logit))
blend_r2 = float(r2_score(y_prob, blend_p))

print("Fixed 50:50 logit-blend R²:", round(blend_r2,3))

# Existing v2 result for comparison
old_p = np.asarray(stack_p, float)
old_r2 = float(r2_score(y_prob, old_p))

candidates = {
    "v2_concept_stack": old_p,
    "v3_classical_bag_stack": classical_p,
    "v3_neural_bag_student": deep_p,
    "v3_fixed_logit_blend": blend_p,
}

metric_rows = []
for name, pp in candidates.items():
    metric_rows.append({
        "candidate": name,
        "nested_oof_r2_probability": float(r2_score(y_prob, pp)),
        "nested_oof_mae": float(mean_absolute_error(y_prob, pp)),
        "nested_oof_rmse": float(np.sqrt(mean_squared_error(y_prob, pp))),
        "binary_agreement_0p5": float(((pp>=0.5)==(y_prob>=0.5)).mean()),
        "pearson_r": float(np.corrcoef(pp,y_prob)[0,1]),
    })

mdf = pd.DataFrame(metric_rows).sort_values(
    "nested_oof_r2_probability", ascending=False
)
mdf.to_csv(BOOST/"R2_BOOSTER_NESTED_CV_COMPARISON.csv", index=False)

# Transparent development selection among prespecified candidates.
best_name = str(mdf.iloc[0]["candidate"])
best_p = candidates[best_name]
best_r2 = float(mdf.iloc[0]["nested_oof_r2_probability"])

print("\n=== R² BOOSTER RESULTS ===")
print(mdf.to_string(index=False))
print("\nBest DEVELOPMENT candidate:", best_name)
print("Best nested OOF R²:", round(best_r2,3))

# Update variables used by the remaining v2 report.
stack_p = np.asarray(best_p, float)
stack_metrics = {
    "model": best_name,
    "nested_oof_r2_probability": best_r2,
    "nested_oof_mae": float(mean_absolute_error(y_prob,best_p)),
    "nested_oof_rmse": float(np.sqrt(mean_squared_error(y_prob,best_p))),
    "binary_agreement_0p5": float(((best_p>=0.5)==(y_prob>=0.5)).mean()),
    "pearson_r": float(np.corrcoef(best_p,y_prob)[0,1]),
}

boost_oof = pd.DataFrame({
    "patient_id": meta["patient_id"].astype(str),
    "teacher_probability": y_prob,
    "v2_concept_stack_oof": old_p,
    "v3_classical_stack_oof": classical_p,
    "v3_neural_bag_student_oof": deep_p,
    "v3_fixed_blend_oof": blend_p,
    "selected_best_oof": best_p,
})
boost_oof.to_csv(BOOST/"R2_BOOSTER_OOF_PREDICTIONS.csv", index=False)

summary = {
    "previous_nested_r2": old_r2,
    "classical_nested_r2": classical_r2,
    "neural_bag_nested_r2": deep_r2,
    "fixed_blend_nested_r2": blend_r2,
    "selected_development_candidate": best_name,
    "selected_nested_r2": best_r2,
    "selected_binary_agreement": stack_metrics["binary_agreement_0p5"],
    "outer_folds": 5,
    "teacher_outcome_labels_used": False,
    "external_labels_used": False,
    "selection_note": (
        "Best candidate selected transparently from prespecified nested-CV "
        "development distillation candidates. This is a development fidelity "
        "estimate, not an independent clinical-performance endpoint."
    ),
}
json.dump(summary, open(BOOST/"R2_BOOSTER_SUMMARY.json","w"), indent=2)

# ----------------------------------------------------------------------
# 5) Fit deployable final v3 neural student ensemble on ALL explanation data.
#    This is for app/explainer deployment, not for estimating R².
# ----------------------------------------------------------------------
final_mu = BAGS.reshape(-1,D).mean(axis=0)
final_sd = BAGS.reshape(-1,D).std(axis=0) + 1e-6
final_epoch = int(np.median(chosen_epochs))
final_epoch = int(np.clip(final_epoch, 40, 280))

final_states = []
for seedoff in [111, 333, 777]:
    fm = train_fixed_epochs(
        BAGS, y_logit,
        final_mu, final_sd,
        final_epoch,
        SEED + seedoff
    )
    state_path = BOOST/f"FINAL_NEURAL_BAG_STUDENT_seed{seedoff}.pt"
    torch.save(fm.state_dict(), state_path)
    final_states.append(str(state_path))
    del fm
    if DEVICE == "cuda":
        torch.cuda.empty_cache()
    gc.collect()

np.savez_compressed(
    BOOST/"FINAL_NEURAL_BAG_STUDENT_PREPROCESS.npz",
    mean=final_mu.astype(np.float32),
    std=final_sd.astype(np.float32),
    epochs=np.array([final_epoch],dtype=np.int32),
)

json.dump(
    {
        "architecture":"BagStudent",
        "d_in":int(D),
        "hidden":96,
        "ensemble_seeds":[111,333,777],
        "state_files":final_states,
        "training_epochs":final_epoch,
        "target":"locked B-v6 PRO teacher logit",
    },
    open(BOOST/"FINAL_NEURAL_BAG_STUDENT_CONFIG.json","w"),
    indent=2
)

# ----------------------------------------------------------------------
# 6) Patch the Phase-7 formatting typo so the original script can resume.
# ----------------------------------------------------------------------
orig = Path("/content/AgentB_Final_Mechanistic_Distillation_v2.py")
if orig.exists():
    src = orig.read_text(encoding="utf-8")
    src = src.replace(
        'f"  {formula_model.coef_[j]:+ .8f} * {basis_names[j]}"',
        'f"  {formula_model.coef_[j]:+.8f} * {basis_names[j]}"'
    )
    orig.write_text(src, encoding="utf-8")
    print("\n✅ Original Phase-7 format typo patched.")

print("\n"+"="*78)
print("✅ R² BOOSTER v3 COMPLETE")
print("Previous nested R²:", round(old_r2,3))
print("Classical bag-stack R²:", round(classical_r2,3))
print("Neural bag-student R²:", round(deep_r2,3))
print("Fixed blend R²:", round(blend_r2,3))
print("SELECTED DEVELOPMENT R²:", round(best_r2,3))
print("Selected model:", best_name)
print("="*78)
print("\nNEXT: run the Phase-7 resume cell. Do NOT rerun Phases 0–6.")


# B-v6 PRO FINALIZER — run in SAME Colab runtime after successful B-v6
# No backbone retraining. No test-set tuning.
# Adds OOF calibration + uncertainty metadata + frozen final package.

import json, math, shutil, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, brier_score_loss, log_loss

ROOT = Path("/content/Bv6_Fast_VolumeMIL")
RES  = ROOT / "results"
OUT  = Path("/content/Prostate_T2_Agent_B_v6_PRO_FINAL")
OUT.mkdir(parents=True, exist_ok=True)

# Require successful B-v6 runtime state.
required = ["oof", "Y", "fold_states"]
missing = [x for x in required if x not in globals()]
if missing:
    raise RuntimeError(
        "Keep the SAME Colab runtime after B-v6. Missing: " + ", ".join(missing)
    )

oof_p = np.asarray(oof, float)
y_dev = np.asarray(Y, int)

def logit(p):
    p = np.clip(np.asarray(p,float), 1e-6, 1-1e-6)
    return np.log(p/(1-p))

# 1) OOF Platt calibration — fitted ONLY on development OOF predictions.
cal = LogisticRegression(C=1e6, solver="lbfgs", max_iter=5000)
cal.fit(logit(oof_p).reshape(-1,1), y_dev)
oof_cal = cal.predict_proba(logit(oof_p).reshape(-1,1))[:,1]

cal_report = {
    "development_n": int(len(y_dev)),
    "oof_auc_raw": float(roc_auc_score(y_dev, oof_p)),
    "oof_auc_calibrated": float(roc_auc_score(y_dev, oof_cal)),
    "oof_brier_raw": float(brier_score_loss(y_dev, oof_p)),
    "oof_brier_calibrated": float(brier_score_loss(y_dev, oof_cal)),
    "oof_logloss_raw": float(log_loss(y_dev, oof_p)),
    "oof_logloss_calibrated": float(log_loss(y_dev, oof_cal)),
    "calibration_source": "development OOF only",
    "test_set_used_for_calibration": False,
}
joblib.dump(cal, OUT/"BV6_PRO_PLATT_CALIBRATOR.joblib")
json.dump(cal_report, open(OUT/"BV6_PRO_CALIBRATION_REPORT.json","w"), indent=2)

# 2) Copy frozen MIL heads + final test metrics.
heads = RES/"BV6_ROBUST_MIL_HEADS.pt"
metrics = RES/"BV6_FRESH_UCLA_FINAL_METRICS.json"
if heads.exists():
    shutil.copy2(heads, OUT/heads.name)
if metrics.exists():
    shutil.copy2(metrics, OUT/metrics.name)

# 3) Save deployment lock.
head_sha = hashlib.sha256((OUT/"BV6_ROBUST_MIL_HEADS.pt").read_bytes()).hexdigest()
lock = {
    "model_name": "Prostate T2 Agent B-v6 PRO",
    "task": "T2-weighted prostate MRI: any-cancer discrimination",
    "architecture": "Frozen DINOv2 slice encoder + prostate-centered 12-slice gated-attention Volume-MIL ensemble",
    "backbone_frozen": True,
    "num_fold_heads": int(len(fold_states)),
    "calibration": "Platt scaling fitted on development OOF predictions only",
    "primary_endpoint": "Any prostate cancer",
    "cspca_endpoint_supported": False,
    "reason_cspca_not_supported": "Held-out csPCa ROC-AUC was near chance.",
    "test_set_tuning": False,
    "heads_sha256": head_sha,
}
json.dump(lock, open(OUT/"BV6_PRO_MODEL_LOCK.json","w"), indent=2)

# 4) Concise professional model card.
testm = json.load(open(metrics)) if metrics.exists() else {}
auc = testm.get("any_cancer",{}).get("bv6_volume_mil",{}).get("roc_auc",None)
ci  = testm.get("any_cancer",{}).get("bv6_volume_mil",{}).get("roc_auc_ci95",None)
n   = testm.get("any_cancer",{}).get("bv6_volume_mil",{}).get("n",None)

card = f"""# Prostate T2 Agent B-v6 PRO

## Intended use
Research-only binary discrimination of **any prostate cancer vs non-cancer** from T2-weighted prostate MRI.

## Architecture
- Frozen DINOv2 image encoder
- 12 prostate-centered slices per MRI volume
- Gated-attention Volume-MIL
- Five-fold ensemble
- OOF Platt probability calibration
- No backbone retraining

## Locked held-out result
- N = {n}
- ROC-AUC = {auc}
- 95% CI = {ci}

## Important limitation
The current UCLA evaluation is patient-disjoint but comes from the same collection used for part of model development. It is **not** an independent external validation.

## Endpoint limitation
The model is locked for the **any-cancer** endpoint. The current data do not support a strong csPCa claim.

## Final validation requirement
Before claiming independent generalization, evaluate this exact locked model once on a new independent cohort without further tuning.
"""
(OUT/"MODEL_CARD.md").write_text(card, encoding="utf-8")

# 5) Export
zip_path = shutil.make_archive(str(OUT), "zip", OUT)

print("="*68)
print("✅ B-v6 PRO FINALIZED — NO TEST-SET TUNING")
print("Development OOF AUC raw/calibrated:",
      round(cal_report["oof_auc_raw"],3),
      round(cal_report["oof_auc_calibrated"],3))
print("Development Brier raw/calibrated:",
      round(cal_report["oof_brier_raw"],3),
      round(cal_report["oof_brier_calibrated"],3))
if auc is not None:
    print("Locked UCLA any-cancer AUC:", round(float(auc),3))
print("Primary endpoint: ANY CANCER")
print("csPCa claim: NOT SUPPORTED")
print("="*68)
print("Final package:", zip_path)

try:
    from google.colab import files
    files.download(zip_path)
except Exception:
    pass

from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import ExtraTreesRegressor, HistGradientBoostingRegressor, RandomForestRegressor, RandomForestRegressor, StackingRegressor, VotingRegressor, GradientBoostingRegressor, RandomForestRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.linear_model import OrthogonalMatchingPursuit, Ridge, ElasticNet
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, ParameterGrid, KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures, StandardScaler

ROOT = Path("analysis_input")
OUT = Path("deep_interpretable_results")
OUT.mkdir(exist_ok=True)
SEED = 20260918


def metric(y, p):
    return dict(
        r2=float(r2_score(y, p)),
        mae=float(mean_absolute_error(y, p)),
        pearson_r=float(np.corrcoef(y, p)[0, 1]),
        agreement_0p5=float(np.mean((y >= .5) == (p >= .5))),
    )


def nested(est, grid, X, y):
    outer = KFold(5, shuffle=True, random_state=SEED)
    p = np.zeros(len(y))
    chosen = []
    for fold, (tr, te) in enumerate(outer.split(X), 1):
        inner = KFold(4, shuffle=True, random_state=SEED + fold)
        n_grid = len(list(ParameterGrid(grid)))
        if n_grid > 100:
            gs = RandomizedSearchCV(est, grid, n_iter=60, scoring="r2", cv=inner, n_jobs=-1,
                                    refit=True, error_score="raise", random_state=SEED + fold)
        else:
            gs = GridSearchCV(est, grid, scoring="r2", cv=inner, n_jobs=-1, refit=True, error_score="raise")
        gs.fit(X[tr], y[tr])
        p[te] = gs.predict(X[te])
        chosen.append(gs.best_params_)
    return np.clip(p, 0, 1), chosen


eng = pd.read_csv(ROOT / "interpretable_engineered_features.csv")
sae = pd.read_csv(ROOT / "SAE_CONCEPT_FEATURES.csv")
df = eng.merge(sae, on="patient_id", validate="one_to_one")
y = df.pop("teacher_probability").to_numpy(float)
ids = df.pop("patient_id").to_numpy()
names = np.array(df.columns)
X = df.to_numpy(float)

front = [("imp", SimpleImputer(strategy="median")), ("sel", SelectKBest(f_regression))]

# Exact-term-count polynomial formula via orthogonal matching pursuit.
omp = Pipeline(front + [
    ("scale", StandardScaler()),
    ("poly", PolynomialFeatures(2, include_bias=False)),
    ("poly_scale", StandardScaler()),
    ("reg", OrthogonalMatchingPursuit(fit_intercept=True)),
])
omp_grid = {
    "sel__k": [12, 16, 20, 24, 32],
    "reg__n_nonzero_coefs": [14, 20, 30, 40, 60, 80],
}

# Tree ensembles: accuracy ceiling for rule-based explanations. These remain
# ensembles, not single glass-box trees.
extra = Pipeline(front + [("model", ExtraTreesRegressor(random_state=SEED, n_jobs=1))])
extra_grid = {
    "sel__k": [12, 24, 36, 64, 96, "all"],
    "model__n_estimators": [300],
    "model__max_depth": [5, 8, 12, None],
    "model__min_samples_leaf": [2, 4, 8, 12],
    "model__max_features": [0.4, 0.7, 1.0],
}

rf = Pipeline(front + [("model", RandomForestRegressor(random_state=SEED, n_jobs=1))])
rf_grid = {
    "sel__k": [12, 24, 36, 64, 96, "all"],
    "model__n_estimators": [300],
    "model__max_depth": [5, 8, 12, None],
    "model__min_samples_leaf": [2, 4, 8, 12],
    "model__max_features": [0.4, 0.7, 1.0],
}

hist = Pipeline(front + [("model", HistGradientBoostingRegressor(random_state=SEED, early_stopping=False))])
hist_grid = {
    "sel__k": [12, 24, 36, 64, 96, "all"],
    "model__max_iter": [100, 200, 350],
    "model__learning_rate": [.02, .05, .1],
    "model__max_leaf_nodes": [5, 9, 15, 25],
    "model__l2_regularization": [0., .1, 1., 10.],
    "model__min_samples_leaf": [10, 20, 30],
}

models = {
    "exact_sparse_polynomial_formula": (omp, omp_grid),
    "extra_trees_rule_ensemble": (extra, extra_grid),
    "random_forest_rule_ensemble": (rf, rf_grid),
    "hist_gradient_rule_ensemble": (hist, hist_grid),
}

rows = []
preds = pd.DataFrame({"patient_id": ids, "teacher_probability": y})
params = {}
for label, (est, grid) in models.items():
    p, selected = nested(est, grid, X, y)
    rows.append({"model": label, **metric(y, p)})
    preds[label] = p
    params[label] = selected
    print(label, rows[-1], flush=True)

pd.DataFrame(rows).sort_values("r2", ascending=False).to_csv(OUT / "DEEP_NESTED_OOF_METRICS.csv", index=False)
preds.to_csv(OUT / "DEEP_NESTED_OOF_PREDICTIONS.csv", index=False)
(OUT / "DEEP_INNER_PARAMS.json").write_text(json.dumps(params, indent=2), encoding="utf-8")

for label, (est, _) in models.items():
    enc = [json.dumps(x, sort_keys=True) for x in params[label]]
    modal = json.loads(max(set(enc), key=enc.count))
    fitted = clone(est).set_params(**modal).fit(X, y)
    joblib.dump(fitted, OUT / f"{label}.joblib")
    (OUT / f"{label}_params.json").write_text(json.dumps(modal, indent=2), encoding="utf-8")

(OUT / "README_VALIDATION.txt").write_text(
    "All reported metrics are five-fold outer OOF estimates with four-fold inner hyperparameter selection. "
    "Feature selection was performed inside training folds. The rule ensembles are interpretable with post-hoc "
    "global/local attribution but are not single glass-box trees.\n",
    encoding="utf-8",
)

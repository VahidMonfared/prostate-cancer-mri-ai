
# B-v6 PRO RESTORE FOR T4 — no retraining
# Required in /content:
# 1) Prostate_T2_Agent_B_v6_PRO_FINAL.zip
# 2) PI_CAI_Bv3_Hidden_Test_Submission_Source.zip

import os, json, zipfile, shutil, importlib.util, subprocess, sys
from pathlib import Path
from contextlib import nullcontext

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torchvision import transforms
import timm
import joblib

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
print("DEVICE:", DEVICE)
if DEVICE == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))

ROOT = Path("/content/BV6_PRO_RESTORE")
ROOT.mkdir(parents=True, exist_ok=True)
SRC = ROOT/"bv3_source"
BUNDLE = Path("/opt/algorithm/bv3_bundle")

v6zip = Path("/content/Prostate_T2_Agent_B_v6_PRO_FINAL.zip")
b3zip = Path("/content/PI_CAI_Bv3_Hidden_Test_Submission_Source.zip")
assert v6zip.exists(), f"Missing {v6zip.name}"
assert b3zip.exists(), f"Missing {b3zip.name}"

def safe_extract(zpath, dest):
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    root = dest.resolve()
    with zipfile.ZipFile(zpath) as z:
        for m in z.infolist():
            tgt = (dest / m.filename).resolve()
            if tgt != root and root not in tgt.parents:
                raise RuntimeError("Unsafe ZIP member: " + m.filename)
        z.extractall(dest)

# Extract v6 package
V6 = ROOT/"v6"
shutil.rmtree(V6, ignore_errors=True)
safe_extract(v6zip, V6)

# Extract B-v3 source + exact bundle
shutil.rmtree(SRC, ignore_errors=True)
safe_extract(b3zip, SRC)
proc_hits = list(SRC.rglob("process.py"))
if not proc_hits:
    raise FileNotFoundError("process.py not found in B-v3 source zip")
SOURCE_ROOT = proc_hits[0].parent

bundle_src = SOURCE_ROOT/"bv3_bundle"
if not bundle_src.exists():
    raise FileNotFoundError("bv3_bundle missing in B-v3 source zip")
shutil.rmtree(BUNDLE, ignore_errors=True)
BUNDLE.parent.mkdir(parents=True, exist_ok=True)
shutil.copytree(bundle_src, BUNDLE)

# Patch torch.load compatibility
txt = (SOURCE_ROOT/"process.py").read_text(encoding="utf-8")
txt = txt.replace('map_location="cpu")', 'map_location="cpu", weights_only=False)')
patched = ROOT/"process_patched.py"
patched.write_text(txt, encoding="utf-8")

spec = importlib.util.spec_from_file_location("bv3proc", patched)
bv3proc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bv3proc)
bv3 = bv3proc.LockedBv3()
print("✅ Locked B-v3 restored")

# DINOv2 frozen 224x224
DINO_NAME = "vit_small_patch14_dinov2.lvd142m"
dino = timm.create_model(
    DINO_NAME,
    pretrained=True,
    num_classes=0,
    global_pool="token",
    img_size=224
).to(DEVICE).eval()
for p in dino.parameters():
    p.requires_grad = False

DINO_TF = transforms.Compose([
    transforms.Resize((224,224)),
    transforms.ToTensor(),
    transforms.Normalize([0.485,0.456,0.406],[0.229,0.224,0.225]),
])
print("✅ Frozen DINOv2 restored")

# B-v6 architecture EXACT
class RobustMIL(nn.Module):
    def __init__(self,d=384,h=128):
        super().__init__()
        self.norm=nn.LayerNorm(d)
        self.proj=nn.Sequential(
            nn.Linear(d,h), nn.GELU(), nn.Dropout(0.20),
            nn.LayerNorm(h)
        )
        self.gate_v=nn.Linear(h,64)
        self.gate_u=nn.Linear(h,64)
        self.attn=nn.Linear(64,1)
        self.cls=nn.Sequential(
            nn.Linear(h*3,128), nn.GELU(), nn.Dropout(0.25),
            nn.Linear(128,1)
        )
    def forward(self,x):
        h=self.proj(self.norm(x))
        a=torch.tanh(self.gate_v(h))*torch.sigmoid(self.gate_u(h))
        a=torch.softmax(self.attn(a).squeeze(-1),dim=1)
        att=(h*a.unsqueeze(-1)).sum(1)
        mean=h.mean(1)
        mx=h.max(1).values
        logit=self.cls(torch.cat([att,mean,mx],dim=1)).squeeze(-1)
        return logit,a

head_file = next(V6.rglob("BV6_ROBUST_MIL_HEADS.pt"))
pack = torch.load(head_file, map_location="cpu", weights_only=False)
fold_states = pack["fold_states"]

models=[]
for st in fold_states:
    m=RobustMIL(d=384).to(DEVICE)
    m.load_state_dict(st)
    m.eval()
    models.append(m)
print("✅ B-v6 five-fold Volume-MIL restored")

cal_file = next(V6.rglob("BV6_PRO_PLATT_CALIBRATOR.joblib"))
calibrator = joblib.load(cal_file)
print("✅ OOF calibrator restored")

K = 12

@torch.inference_mode()
def dino_batch_u8(u8s):
    x = torch.stack([
        DINO_TF(Image.fromarray(u).convert("RGB")) for u in u8s
    ]).to(DEVICE)
    ctx = torch.autocast("cuda", dtype=torch.float16) if DEVICE=="cuda" else nullcontext()
    with ctx:
        return dino(x).float().cpu().numpy()

def select_slices(vol, k=K):
    slices=[bv3proc.robust_uint8(vol[z]) for z in range(vol.shape[0])]
    masks,valid=bv3.segment(slices)
    areas=np.array([float(m.sum()) if v else 0.0 for m,v in zip(masks,valid)])
    if areas.max() <= 0:
        c=len(slices)//2
        idx=np.arange(max(0,c-k//2), min(len(slices),c+(k+1)//2))
    else:
        idx=np.sort(np.argsort(-areas)[:min(k,len(slices))])
    if len(idx)==0:
        idx=np.array([len(slices)//2])
    while len(idx)<k:
        idx=np.r_[idx,idx[-1]]
    return slices,masks,valid,idx[:k]

@torch.inference_mode()
def volume_to_bag(vol):
    slices,masks,valid,idx=select_slices(vol,K)
    crops=[]
    for z in idx:
        u=slices[int(z)]
        if valid[int(z)] and np.asarray(masks[int(z)]).any():
            try:
                u=bv3proc.crop_roi(u,masks[int(z)])
            except Exception:
                pass
        crops.append(u)
    feats=[]
    for s in range(0,len(crops),16):
        feats.append(dino_batch_u8(crops[s:s+16]))
    return np.concatenate(feats,axis=0).astype(np.float32)

@torch.inference_mode()
def predict_bv6_volume(vol):
    bag=volume_to_bag(vol)
    x=torch.tensor(bag[None,...],dtype=torch.float32,device=DEVICE)
    fold_probs=np.array([torch.sigmoid(m(x)[0]).item() for m in models],float)
    raw=float(fold_probs.mean())
    p=np.clip(raw,1e-6,1-1e-6)
    logit=np.log(p/(1-p))
    calibrated=float(calibrator.predict_proba([[logit]])[0,1])
    uncertainty=float(fold_probs.std())
    return {
        "raw_probability": raw,
        "calibrated_probability": calibrated,
        "fold_std_uncertainty": uncertainty,
        "fold_probabilities": fold_probs.tolist(),
    }

# sanity check
x=torch.randn(1,3,224,224,device=DEVICE)
with torch.no_grad():
    y=dino(x)
assert y.shape[-1]==384

print("\n"+"="*64)
print("✅ B-v6 PRO READY ON T4 — NO RETRAINING")
print("Use raw_probability for ROC-AUC ranking.")
print("Use calibrated_probability for reported probability/risk.")
print("="*64)

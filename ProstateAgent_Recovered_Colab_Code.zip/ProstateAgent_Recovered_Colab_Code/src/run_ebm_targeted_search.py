from __future__ import annotations

import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from interpret.glassbox import ExplainableBoostingRegressor
from sklearn.base import clone
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.feature_selection import SelectKBest, f_regression
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import KFold, RandomizedSearchCV
from sklearn.pipeline import Pipeline

ROOT = Path("analysis_input")
OUT = Path("deep_interpretable_results")
SEED = 20260918


def score(y, p):
    return {
        "r2": float(r2_score(y, p)),
        "mae": float(mean_absolute_error(y, p)),
        "pearson_r": float(np.corrcoef(y, p)[0, 1]),
        "agreement_0p5": float(np.mean((y >= .5) == (p >= .5))),
    }


def nested(label, estimator, distributions, X, y, n_iter):
    outer = KFold(5, shuffle=True, random_state=SEED)
    pred = np.zeros(len(y))
    selected = []
    for fold, (tr, te) in enumerate(outer.split(X), 1):
        inner = KFold(4, shuffle=True, random_state=SEED + fold)
        rs = RandomizedSearchCV(estimator, distributions, n_iter=n_iter, scoring="r2", cv=inner,
                                n_jobs=-1, refit=True, random_state=SEED + fold, error_score="raise")
        rs.fit(X[tr], y[tr])
        pred[te] = rs.predict(X[te])
        selected.append(rs.best_params_)
        print(label, "fold", fold, rs.best_score_, rs.best_params_, flush=True)
    pred = np.clip(pred, 0, 1)
    return pred, selected


eng = pd.read_csv(ROOT / "interpretable_engineered_features.csv")
sae = pd.read_csv(ROOT / "SAE_CONCEPT_FEATURES.csv")
df = eng.merge(sae, on="patient_id", validate="one_to_one")
y = df.pop("teacher_probability").to_numpy(float)
ids = df.pop("patient_id").to_numpy()
names = list(df.columns)
X = df.to_numpy(float)

ebm = Pipeline([
    ("impute", SimpleImputer(strategy="median")),
    ("select", SelectKBest(f_regression)),
    ("model", ExplainableBoostingRegressor(feature_names=None, n_jobs=1, random_state=SEED,
                                             max_rounds=8000, early_stopping_rounds=100)),
])
ebm_dist = {
    "select__k": [12, 16, 24, 32, 48, 64, 96, "all"],
    "model__interactions": [0, 3, 5, 8, 12, 20],
    "model__max_bins": [16, 32, 64, 128],
    "model__max_interaction_bins": [8, 16, 32],
    "model__learning_rate": [.01, .02, .04, .08],
    "model__max_leaves": [2, 3, 4],
    "model__min_samples_leaf": [4, 8, 12, 20, 30],
    "model__reg_alpha": [0., .001, .01, .1],
    "model__reg_lambda": [0., .01, .1, 1., 10.],
    "model__outer_bags": [8, 12, 16],
}

hist = Pipeline([
    ("impute", SimpleImputer(strategy="median")),
    ("model", HistGradientBoostingRegressor(random_state=SEED, early_stopping=False)),
])
hist_dist = {
    "model__max_iter": [100, 150, 200, 250, 350, 500, 700],
    "model__learning_rate": [.02, .03, .04, .05, .07, .1],
    "model__max_leaf_nodes": [3, 5, 7, 9, 12, 15, 20, 25],
    "model__l2_regularization": [0., .03, .1, .3, 1., 3., 10., 30.],
    "model__min_samples_leaf": [20, 25, 30, 35, 40, 50],
    "model__max_bins": [32, 64, 128, 255],
}

outputs = {}
for label, est, dist, n_iter in [
    ("explainable_boosting_machine", ebm, ebm_dist, 45),
    ("targeted_hist_gradient_rules", hist, hist_dist, 100),
]:
    p, pars = nested(label, est, dist, X, y, n_iter)
    outputs[label] = (p, pars, est)
    print("FINAL", label, score(y, p), flush=True)

pred = pd.DataFrame({"patient_id": ids, "teacher_probability": y})
metrics = []
all_params = {}
for label, (p, pars, est) in outputs.items():
    pred[label] = p
    metrics.append({"model": label, **score(y, p)})
    all_params[label] = pars
    enc = [json.dumps(x, sort_keys=True) for x in pars]
    modal = json.loads(max(set(enc), key=enc.count))
    final = clone(est).set_params(**modal).fit(X, y)
    joblib.dump(final, OUT / f"{label}.joblib")
    (OUT / f"{label}_modal_params.json").write_text(json.dumps(modal, indent=2), encoding="utf-8")

pred.to_csv(OUT / "EBM_TARGETED_OOF_PREDICTIONS.csv", index=False)
pd.DataFrame(metrics).to_csv(OUT / "EBM_TARGETED_OOF_METRICS.csv", index=False)
(OUT / "EBM_TARGETED_INNER_PARAMS.json").write_text(json.dumps(all_params, indent=2), encoding="utf-8")

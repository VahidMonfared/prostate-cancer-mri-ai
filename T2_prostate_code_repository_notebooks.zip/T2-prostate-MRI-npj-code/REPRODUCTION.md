# Reproduction record

Both headline notebooks were executed from a clean checkout of this repository, from the committed
feature tables only, and their output is saved inside the notebook files. Open them on GitHub and
the numbers are visible without running anything.

## Notebook 02 — internal result

Re-ran `02_internal_nested_cv_AUC_0.924.ipynb`. Output compared against the recorded run in
`results/internal_results.json`:

| quantity | recorded | re-run |
|---|---|---|
| nested AUC mean | 0.9157966101694914 | 0.9157966101694914 |
| nested AUC sd | 0.013636458558251739 | 0.013636458558251739 |
| **pooled out-of-fold AUC** | **0.923728813559322** | **0.923728813559322** |
| pooled average precision | 0.917609613089226 | 0.917609613089226 |
| 95% CI | 0.888607125178262 – 0.9526269130626679 | 0.888607125178262 – 0.9526269130626679 |

Per-repeat AUCs: 0.9236, 0.9173, 0.9254, 0.9237, 0.8891.
Confusion matrix at the Youden threshold 0.4946: TN 107, FP 18, FN 17, TP 101.

**Bit-identical.** The analysis is seeded (`SEED = 20260919`) and deterministic.

## Notebook 08 — external result

Re-ran `08_external_Prostate158_AUC_0.643.ipynb`. Printed output:

```
internal merged (243, 1322) | external merged (137, 1323)
C_v3_gland_aligned: internal 0.8598 -> external 0.6432 (0.545-0.734)
D_v2_plus_lesion:   internal 0.9140 -> external 0.5947 (0.492-0.690)
```

Model C at the locked threshold 0.3501: TN 8, FP 47, FN 4, TP 78; sensitivity 0.9512,
specificity 0.1455, PPV 0.624, NPV 0.6667, accuracy 0.6277, F1 0.7536, Brier 0.2298,
average precision 0.7276.

Matches `results/p158_results_CD.json` exactly.

## Environment used for the re-run

Python 3.11, numpy / pandas / scikit-learn / scikit-image / PyWavelets / pyarrow / joblib as pinned
in `requirements.txt`. No GPU required for either notebook.

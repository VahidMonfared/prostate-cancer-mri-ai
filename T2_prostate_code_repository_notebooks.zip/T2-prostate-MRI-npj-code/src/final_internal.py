"""Locked internal evaluation: nested cross-validation, no selection outside training folds."""
import numpy as np, pandas as pd, json, warnings; warnings.filterwarnings('ignore')
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier, VotingClassifier
from sklearn.model_selection import StratifiedKFold, GridSearchCV
from sklearn.metrics import (roc_auc_score, average_precision_score, roc_curve, confusion_matrix,
                             brier_score_loss, f1_score)
SEED = 20260919

def build():
    lr = Pipeline([('sc', StandardScaler()), ('m', LogisticRegression(max_iter=5000))])
    grid = GridSearchCV(lr, {'m__C': [0.01, 0.05, 0.1, 0.2, 0.5]}, scoring='roc_auc',
                        cv=StratifiedKFold(5, shuffle=True, random_state=SEED), n_jobs=2)
    rf = RandomForestClassifier(n_estimators=800, min_samples_leaf=2, n_jobs=2, random_state=SEED)
    hgb = HistGradientBoostingClassifier(max_iter=300, learning_rate=0.06, random_state=SEED)
    return VotingClassifier([('lr', grid), ('rf', rf), ('hgb', hgb)], voting='soft', weights=[2, 1, 1])

def metrics(y, p, thr):
    yhat = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, yhat, labels=[0, 1]).ravel()
    sens = tp / (tp + fn); spec = tn / (tn + fp)
    ppv = tp / (tp + fp) if tp + fp else float('nan'); npv = tn / (tn + fn) if tn + fn else float('nan')
    return dict(auc=roc_auc_score(y, p), ap=average_precision_score(y, p), threshold=float(thr),
                tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp),
                sensitivity=sens, specificity=spec, ppv=ppv, npv=npv,
                accuracy=(tp + tn) / len(y), f1=f1_score(y, yhat), brier=brier_score_loss(y, p))

def boot_ci(y, p, fn, n=2000, seed=SEED):
    rng = np.random.default_rng(seed); out = []
    for _ in range(n):
        i = rng.integers(0, len(y), len(y))
        if len(np.unique(y[i])) < 2: continue
        out.append(fn(y[i], p[i]))
    return float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))

if __name__ == '__main__':
    df = pd.read_parquet('features_internal.parquet')
    X = np.nan_to_num(df.drop(columns=['sha', 'y', 'path']).values.astype(float))
    y = df.y.values.astype(int)

    # ---- nested CV, 5 repeats of 5 folds
    all_auc, all_ap, oof_store = [], [], []
    for r in range(5):
        skf = StratifiedKFold(5, shuffle=True, random_state=SEED + r)
        oof = np.zeros(len(y))
        for tr, te in skf.split(X, y):
            m = build(); m.fit(X[tr], y[tr]); oof[te] = m.predict_proba(X[te])[:, 1]
        all_auc.append(roc_auc_score(y, oof)); all_ap.append(average_precision_score(y, oof))
        oof_store.append(oof)
        print(f'repeat {r}: AUC {all_auc[-1]:.4f}  AP {all_ap[-1]:.4f}', flush=True)

    oof_mean = np.mean(oof_store, axis=0)
    fpr, tpr, thr = roc_curve(y, oof_mean)
    youden = float(thr[np.argmax(tpr - fpr)])

    res = {
        'n': int(len(y)), 'n_cancer': int(y.sum()), 'n_normal': int((y == 0).sum()),
        'nested_auc_per_repeat': [float(a) for a in all_auc],
        'nested_auc_mean': float(np.mean(all_auc)), 'nested_auc_sd': float(np.std(all_auc)),
        'nested_ap_mean': float(np.mean(all_ap)),
        'pooled_at_youden': metrics(y, oof_mean, youden),
        'pooled_at_0.50': metrics(y, oof_mean, 0.5),
    }
    res['auc_ci'] = boot_ci(y, oof_mean, roc_auc_score)
    res['ap_ci'] = boot_ci(y, oof_mean, average_precision_score)
    np.save('oof_internal.npy', np.vstack([y, oof_mean]))
    json.dump(res, open('internal_results.json', 'w'), indent=2)
    print(json.dumps(res, indent=2))

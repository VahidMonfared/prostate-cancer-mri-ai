"""Unsupervised prostate localiser.

The institutional exports are wide-field screenshots; the Prostate158 exports are tightly
framed. A fixed centre crop therefore samples different anatomy in each dataset, which is a
spatial domain shift on top of the intensity one. This finds the gland in each image using
only image statistics: no labels, no dataset-specific constants, same code for both domains.
"""
import numpy as np, cv2
from scipy import ndimage

def gland_box(g):
    """g: uint8 grayscale, already border-cropped. Returns (y0, y1, x0, x1)."""
    h, w = g.shape
    x = cv2.GaussianBlur(g, (0, 0), max(h, w) / 90.0)
    # the gland is darker than peri-prostatic fat but brighter than air/bone
    lo, hi = np.percentile(x, 20), np.percentile(x, 70)
    band = ((x >= lo) & (x <= hi)).astype(np.uint8)
    band = cv2.morphologyEx(band, cv2.MORPH_OPEN,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9)))
    band = cv2.morphologyEx(band, cv2.MORPH_CLOSE,
                            cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
    lab, n = ndimage.label(band)
    if n == 0:
        s = int(min(h, w) * 0.5)
        return ((h - s) // 2, (h + s) // 2, (w - s) // 2, (w + s) // 2)
    cy, cx = h / 2.0, w / 2.0
    best, score = None, -1e9
    for i in range(1, n + 1):
        ys, xs = np.where(lab == i)
        area = len(ys)
        if area < 0.01 * h * w or area > 0.45 * h * w:
            continue
        my, mx = ys.mean(), xs.mean()
        dist = np.hypot((my - cy) / h, (mx - cx) / w)
        bh, bw = ys.max() - ys.min() + 1, xs.max() - xs.min() + 1
        if bh == 0 or bw == 0:
            continue
        fill = area / (bh * bw)
        ar = min(bh, bw) / max(bh, bw)
        s = np.log(area / (h * w)) - 6.0 * dist + 1.5 * fill + 1.0 * ar
        if s > score:
            score, best = s, (ys.min(), ys.max() + 1, xs.min(), xs.max() + 1)
    if best is None:
        s = int(min(h, w) * 0.5)
        return ((h - s) // 2, (h + s) // 2, (w - s) // 2, (w + s) // 2)
    y0, y1, x0, x1 = best
    # square it up around its centre, with a small margin
    my, mx = (y0 + y1) / 2, (x0 + x1) / 2
    r = max(y1 - y0, x1 - x0) / 2 * 1.20
    y0, y1 = int(max(0, my - r)), int(min(h, my + r))
    x0, x1 = int(max(0, mx - r)), int(min(w, mx + r))
    if y1 - y0 < 24 or x1 - x0 < 24:
        s = int(min(h, w) * 0.5)
        return ((h - s) // 2, (h + s) // 2, (w - s) // 2, (w + s) // 2)
    return (y0, y1, x0, x1)

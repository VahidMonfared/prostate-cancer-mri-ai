"""Shared preprocessing + feature extraction. Used for internal CV and for external evaluation."""
import hashlib, json
from pathlib import Path
import numpy as np, cv2, pywt
from skimage.feature import graycomatrix, graycoprops, local_binary_pattern, hog
from skimage.filters import gabor_kernel
from scipy import ndimage, stats

SIZE = 224
RNG_SEED = 20260919

# ---------------- preprocessing (identical for internal and external data) ----------------
def to_gray(img_rgb):
    if img_rgb.ndim == 3:
        return cv2.cvtColor(img_rgb[:, :, :3].astype(np.uint8), cv2.COLOR_RGB2GRAY)
    return img_rgb.astype(np.uint8)

def crop_border(g, rel=0.06):
    """Remove uniform near-black padding that MRI exports carry.
    The threshold is relative to the image's own intensity range, so it is not
    disturbed by scanner brightness, contrast or gamma differences."""
    lo, hi = np.percentile(g, 2), np.percentile(g, 98)
    thr = lo + rel * max(hi - lo, 1.0)
    mask = g > thr
    if mask.sum() < 100:
        return g
    ys, xs = np.where(mask)
    y0, y1, x0, x1 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
    if (y1 - y0) < 32 or (x1 - x0) < 32:
        return g
    return g[y0:y1, x0:x1]

def letterbox(g, size=SIZE):
    h, w = g.shape
    s = size / max(h, w)
    nh, nw = max(1, int(round(h * s))), max(1, int(round(w * s)))
    r = cv2.resize(g, (nw, nh), interpolation=cv2.INTER_AREA)
    out = np.zeros((size, size), np.uint8)
    out[(size - nh) // 2:(size - nh) // 2 + nh, (size - nw) // 2:(size - nw) // 2 + nw] = r
    return out

def robust_norm(g):
    """Per-image intensity standardisation: the step that matters for cross-scanner transfer."""
    x = g.astype(np.float32)
    lo, hi = np.percentile(x, 1), np.percentile(x, 99)
    if hi - lo < 1e-6:
        hi = lo + 1.0
    x = np.clip((x - lo) / (hi - lo), 0, 1)
    return x


def rank_norm(g):
    """Replace each pixel by its within-image rank. Invariant to ANY monotone intensity
    transform, so scanner brightness, contrast and gamma differences cancel out."""
    x = g.astype(np.float32).ravel()
    order = np.argsort(np.argsort(x, kind='stable'), kind='stable').astype(np.float32)
    return (order / (len(x) - 1)).reshape(g.shape)

def center_view(x, frac=0.55):
    """Central region: in axial T2 exports the prostate sits near the image centre."""
    h, w = x.shape
    ch, cw = int(h * frac), int(w * frac)
    y0, x0 = (h - ch) // 2, (w - cw) // 2
    c = x[y0:y0 + ch, x0:x0 + cw]
    return cv2.resize(c, (SIZE, SIZE), interpolation=cv2.INTER_AREA)

def preprocess(img_rgb):
    g = letterbox(crop_border(to_gray(img_rgb)))
    x = robust_norm(g)
    q = rank_norm(g)
    return x, center_view(x), q, center_view(q)

# ---------------- features ----------------
_GABOR = [np.real(gabor_kernel(f, theta=t, sigma_x=3, sigma_y=3))
          for f in (0.10, 0.20, 0.35) for t in np.arange(0, np.pi, np.pi / 4)]

def _glcm_feats(u8, prefix, out):
    for d in (1, 3, 5):
        gl = graycomatrix(u8, [d], [0, np.pi/4, np.pi/2, 3*np.pi/4], levels=32,
                          symmetric=True, normed=True)
        for prop in ('contrast', 'dissimilarity', 'homogeneity', 'energy', 'correlation', 'ASM'):
            v = graycoprops(gl, prop)[0]
            out[f'{prefix}glcm_{prop}_d{d}_mean'] = float(v.mean())
            out[f'{prefix}glcm_{prop}_d{d}_std'] = float(v.std())

def _lbp_feats(x, prefix, out):
    for R, P in ((1, 8), (2, 16), (3, 24)):
        lbp = local_binary_pattern((x * 255).astype(np.uint8), P, R, method='uniform')
        h, _ = np.histogram(lbp, bins=P + 2, range=(0, P + 2), density=True)
        for i, v in enumerate(h):
            out[f'{prefix}lbp_R{R}_{i}'] = float(v)

def _intensity_feats(x, prefix, out):
    v = x.ravel()
    for p in (1, 5, 10, 25, 50, 75, 90, 95, 99):
        out[f'{prefix}p{p}'] = float(np.percentile(v, p))
    out[f'{prefix}mean'] = float(v.mean()); out[f'{prefix}std'] = float(v.std())
    out[f'{prefix}skew'] = float(stats.skew(v)); out[f'{prefix}kurt'] = float(stats.kurtosis(v))
    hist, _ = np.histogram(v, bins=32, range=(0, 1), density=True)
    hist = hist / (hist.sum() + 1e-9)
    out[f'{prefix}entropy'] = float(-(hist * np.log(hist + 1e-9)).sum())
    for i, h in enumerate(hist):
        out[f'{prefix}hist{i}'] = float(h)

def _edge_feats(x, prefix, out):
    gx = cv2.Sobel(x, cv2.CV_32F, 1, 0, 3); gy = cv2.Sobel(x, cv2.CV_32F, 0, 1, 3)
    mag = np.sqrt(gx ** 2 + gy ** 2)
    out[f'{prefix}grad_mean'] = float(mag.mean()); out[f'{prefix}grad_std'] = float(mag.std())
    out[f'{prefix}grad_p90'] = float(np.percentile(mag, 90))
    out[f'{prefix}lap_var'] = float(cv2.Laplacian(x, cv2.CV_32F).var())
    out[f'{prefix}edge_density'] = float((mag > np.percentile(mag, 90)).mean())

def _gabor_feats(x, prefix, out):
    for i, k in enumerate(_GABOR):
        r = ndimage.convolve(x, k, mode='reflect')
        out[f'{prefix}gabor{i}_mean'] = float(np.abs(r).mean())
        out[f'{prefix}gabor{i}_std'] = float(r.std())

def _wavelet_feats(x, prefix, out):
    c = pywt.wavedec2(x, 'db2', level=3)
    out[f'{prefix}wav_a_energy'] = float((c[0] ** 2).mean())
    for lvl, det in enumerate(c[1:], start=1):
        for name, d in zip(('h', 'v', 'd'), det):
            out[f'{prefix}wav_l{lvl}{name}_energy'] = float((d ** 2).mean())
            out[f'{prefix}wav_l{lvl}{name}_std'] = float(d.std())

def _hog_feats(x, prefix, out):
    h = hog(x, orientations=9, pixels_per_cell=(32, 32), cells_per_block=(2, 2),
            block_norm='L2-Hys', feature_vector=True)
    h = h.reshape(-1, 9).mean(0) if h.size % 9 == 0 else h[:9]
    for i, v in enumerate(h):
        out[f'{prefix}hog{i}'] = float(v)

def features(img_rgb):
    whole, centre, rwhole, rcentre = preprocess(img_rgb)
    out = {}
    for x, prefix in ((whole, 'w_'), (centre, 'c_'), (rwhole, 'r_'), (rcentre, 'rc_')):
        u8 = np.clip(x * 31, 0, 31).astype(np.uint8)
        _intensity_feats(x, prefix, out)
        _glcm_feats(u8, prefix, out)
        _lbp_feats(x, prefix, out)
        _edge_feats(x, prefix, out)
        _gabor_feats(x, prefix, out)
        _wavelet_feats(x, prefix, out)
        _hog_feats(x, prefix, out)
    # centre-versus-periphery contrast
    out['ratio_mean'] = out['c_mean'] / (out['w_mean'] + 1e-6)
    out['ratio_p10'] = out['c_p10'] / (out['w_p10'] + 1e-6)
    out['ratio_grad'] = out['c_grad_mean'] / (out['w_grad_mean'] + 1e-6)
    out['rratio_mean'] = out['rc_mean'] / (out['r_mean'] + 1e-6)
    out['rratio_p10'] = out['rc_p10'] / (out['r_p10'] + 1e-6)
    out['rratio_p25'] = out['rc_p25'] / (out['r_p25'] + 1e-6)
    out['rratio_grad'] = out['rc_grad_mean'] / (out['r_grad_mean'] + 1e-6)
    return out

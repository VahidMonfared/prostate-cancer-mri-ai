"""Pipeline v3: gland-aligned views plus lesion-targeted, within-image relative features.

Everything is measured relative to the image itself (ranks, ratios to the gland's own median,
left-right asymmetry), so scanner brightness, contrast and gain cancel by construction.
"""
import numpy as np, cv2, pywt
from scipy import ndimage, stats
from skimage.feature import graycomatrix, graycoprops, local_binary_pattern
import sys
sys.path.insert(0, '/home/claude/work2')
from pipeline import to_gray, crop_border, letterbox, robust_norm, rank_norm
from locate import gland_box

SIZE = 224

def views(img_rgb):
    g0 = crop_border(to_gray(img_rgb))
    y0, y1, x0, x1 = gland_box(g0)
    gland = g0[y0:y1, x0:x1]
    gl = letterbox(gland, SIZE)
    wh = letterbox(g0, SIZE)
    frac = ((y1 - y0) * (x1 - x0)) / float(g0.shape[0] * g0.shape[1])
    return {'g': robust_norm(gl), 'gq': rank_norm(gl),
            'w': robust_norm(wh), 'wq': rank_norm(wh)}, frac

# ---------- generic descriptors
def _stats(x, pre, out):
    v = x.ravel()
    for p in (1, 5, 10, 25, 50, 75, 90, 95, 99):
        out[f'{pre}p{p}'] = float(np.percentile(v, p))
    out[f'{pre}mean'] = float(v.mean()); out[f'{pre}std'] = float(v.std())
    out[f'{pre}skew'] = float(stats.skew(v)); out[f'{pre}kurt'] = float(stats.kurtosis(v))
    out[f'{pre}iqr'] = float(np.percentile(v, 75) - np.percentile(v, 25))
    h, _ = np.histogram(v, bins=24, range=(0, 1), density=True); h = h / (h.sum() + 1e-9)
    out[f'{pre}entropy'] = float(-(h * np.log(h + 1e-9)).sum())
    for i, q in enumerate(h): out[f'{pre}h{i}'] = float(q)

def _texture(x, pre, out):
    u8 = np.clip(x * 31, 0, 31).astype(np.uint8)
    for d in (1, 3, 6):
        gl = graycomatrix(u8, [d], [0, np.pi/4, np.pi/2, 3*np.pi/4], levels=32, symmetric=True, normed=True)
        for prop in ('contrast', 'homogeneity', 'energy', 'correlation'):
            v = graycoprops(gl, prop)[0]
            out[f'{pre}glcm_{prop}_d{d}'] = float(v.mean())
            out[f'{pre}glcm_{prop}_d{d}_sd'] = float(v.std())
    for R, P in ((1, 8), (3, 24)):
        lbp = local_binary_pattern((x * 255).astype(np.uint8), P, R, method='uniform')
        h, _ = np.histogram(lbp, bins=P + 2, range=(0, P + 2), density=True)
        for i, q in enumerate(h): out[f'{pre}lbp{R}_{i}'] = float(q)
    gx = cv2.Sobel(x, cv2.CV_32F, 1, 0, 3); gy = cv2.Sobel(x, cv2.CV_32F, 0, 1, 3)
    mag = np.sqrt(gx ** 2 + gy ** 2)
    out[f'{pre}grad_mean'] = float(mag.mean()); out[f'{pre}grad_sd'] = float(mag.std())
    out[f'{pre}grad_p90'] = float(np.percentile(mag, 90))
    out[f'{pre}lapvar'] = float(cv2.Laplacian(x, cv2.CV_32F).var())
    c = pywt.wavedec2(x, 'db2', level=3)
    tot = sum(float((d ** 2).mean()) for lvl in c[1:] for d in lvl) + 1e-9
    for lvl, det in enumerate(c[1:], 1):
        for nm, d in zip('hvd', det):
            out[f'{pre}wav{lvl}{nm}'] = float((d ** 2).mean()) / tot     # relative energy

# ---------- lesion-targeted, all relative to the gland itself
def _focal(x, pre, out):
    """Focal low-signal foci: the radiological sign of tumour on T2."""
    med = float(np.median(x)); mad = float(np.median(np.abs(x - med))) + 1e-6
    sm = cv2.GaussianBlur(x, (0, 0), 2.0)
    for q in (2, 5, 10, 20):
        thr = np.percentile(sm, q)
        m = (sm <= thr).astype(np.uint8)
        lab, n = ndimage.label(m)
        if n == 0:
            out[f'{pre}foc{q}_area'] = 0.0; out[f'{pre}foc{q}_contrast'] = 0.0
            out[f'{pre}foc{q}_compact'] = 0.0; out[f'{pre}foc{q}_n'] = 0.0
            continue
        sizes = ndimage.sum(m, lab, range(1, n + 1))
        k = int(np.argmax(sizes)) + 1
        ys, xs = np.where(lab == k)
        area = len(ys) / x.size
        contrast = (med - float(x[lab == k].mean())) / mad
        bh, bw = ys.max() - ys.min() + 1, xs.max() - xs.min() + 1
        out[f'{pre}foc{q}_area'] = float(area)
        out[f'{pre}foc{q}_contrast'] = float(contrast)
        out[f'{pre}foc{q}_compact'] = float(len(ys) / (bh * bw))
        out[f'{pre}foc{q}_n'] = float(n)
        out[f'{pre}foc{q}_ecc'] = float(min(bh, bw) / max(bh, bw))
        out[f'{pre}foc{q}_off'] = float(np.hypot(ys.mean() / x.shape[0] - .5, xs.mean() / x.shape[1] - .5))
    out[f'{pre}dark_spread'] = float((np.percentile(x, 50) - np.percentile(x, 2)) / (mad + 1e-6))

def _asym(x, pre, out):
    """Left-right asymmetry: a focal lesion breaks the near-symmetry of the gland."""
    m = cv2.flip(x, 1)
    d = x - m
    out[f'{pre}asym_mad'] = float(np.abs(d).mean())
    out[f'{pre}asym_p95'] = float(np.percentile(np.abs(d), 95))
    a, b = x.ravel(), m.ravel()
    out[f'{pre}asym_corr'] = float(np.corrcoef(a, b)[0, 1]) if a.std() > 0 else 0.0
    h, w = x.shape
    L, R = x[:, :w // 2], cv2.flip(x[:, w - w // 2:], 1)
    for p in (5, 10, 25, 50):
        out[f'{pre}asym_p{p}_diff'] = float(np.percentile(L, p) - np.percentile(R, p))
    out[f'{pre}asym_std_diff'] = float(L.std() - R.std())
    # top vs bottom (anterior versus posterior) as a second axis
    T, B = x[:h // 2], cv2.flip(x[h - h // 2:], 0)
    out[f'{pre}ap_p10_diff'] = float(np.percentile(T, 10) - np.percentile(B, 10))
    out[f'{pre}ap_mean_diff'] = float(T.mean() - B.mean())

def _radial(x, pre, out):
    h, w = x.shape
    yy, xx = np.mgrid[0:h, 0:w]
    r = np.hypot((yy - h / 2) / (h / 2), (xx - w / 2) / (w / 2))
    for lo, hi in ((0, .33), (.33, .66), (.66, 1.0)):
        m = (r >= lo) & (r < hi)
        if m.sum() < 10: continue
        v = x[m]
        out[f'{pre}rad{int(hi*100)}_mean'] = float(v.mean())
        out[f'{pre}rad{int(hi*100)}_p10'] = float(np.percentile(v, 10))
        out[f'{pre}rad{int(hi*100)}_std'] = float(v.std())

def features3(img_rgb):
    V, frac = views(img_rgb)
    out = {'gland_frac': float(frac)}
    for key in ('g', 'gq', 'w', 'wq'):
        x = V[key]; pre = key + '_'
        _stats(x, pre, out); _texture(x, pre, out)
        if key in ('g', 'gq'):
            _focal(x, pre, out); _asym(x, pre, out); _radial(x, pre, out)
    for k in ('mean', 'p10', 'std', 'grad_mean'):
        out[f'ratio_{k}'] = out[f'g_{k}'] / (out[f'w_{k}'] + 1e-6)
    return out

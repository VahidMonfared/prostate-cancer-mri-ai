"""
External evaluation on Prostate158 with a model locked on the institutional cohort.

Nothing here touches Prostate158 during fitting. The model, its calibration and its
threshold are loaded from disk; this script only reads images, extracts the same
features as the internal pipeline, predicts once, and scores.

Expected layout (as distributed by the Prostate158 release):
    <root>/<case_id>/t2.nii.gz
    <root>/<case_id>/t2_anatomy_reader1.nii.gz      (whole-gland / zonal mask)
    <root>/<case_id>/t2_tumor_reader1.nii.gz        (tumour mask, present for annotated cases)
"""
import argparse, json, sys, hashlib
from pathlib import Path
import numpy as np, pandas as pd, joblib, nibabel as nib
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pipeline import features
from final_internal import metrics, boot_ci

def hashlib_sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


TUMOUR_MIN_VOXELS = 20      # a slice counts as positive when the tumour mask covers at least this many voxels
GLAND_MIN_VOXELS  = 50      # a slice is eligible when the gland mask covers at least this many voxels
TOP_K             = 3       # patient score = mean of the K highest slice probabilities


def load_nii(p):
    img = nib.load(str(p))
    return np.asanyarray(img.dataobj).astype(np.float32)


def slice_to_rgb(sl):
    """Match the internal inputs, which were 8-bit grayscale exports."""
    lo, hi = np.percentile(sl, 0.5), np.percentile(sl, 99.5)
    if hi - lo < 1e-6:
        hi = lo + 1.0
    g = np.clip((sl - lo) / (hi - lo), 0, 1)
    g = (g * 255).astype(np.uint8)
    return np.repeat(g[:, :, None], 3, axis=2)


def iter_cases(root):
    for d in sorted(Path(root).iterdir()):
        if not d.is_dir():
            continue
        t2 = d / 't2.nii.gz'
        if not t2.exists():
            continue
        yield d.name, t2, d / 't2_anatomy_reader1.nii.gz', d / 't2_tumor_reader1.nii.gz'


def build_table(root):
    rows = []
    for cid, t2p, glandp, tump in iter_cases(root):
        vol = load_nii(t2p)
        gland = load_nii(glandp) if glandp.exists() else None
        tum = load_nii(tump) if tump.exists() else None
        n_ax = vol.shape[2]
        for k in range(n_ax):
            sl = vol[:, :, k]
            g_vox = int((gland[:, :, k] > 0).sum()) if gland is not None else GLAND_MIN_VOXELS
            if g_vox < GLAND_MIN_VOXELS:
                continue
            t_vox = int((tum[:, :, k] > 0).sum()) if tum is not None else 0
            rows.append(dict(case=cid, slice=k, gland_vox=g_vox, tumour_vox=t_vox,
                             has_tumour_case=int(tum is not None and (tum > 0).sum() > 0),
                             **features(slice_to_rgb(sl))))
        print(f'{cid}: {n_ax} axial slices', flush=True)
    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True, help='Prostate158 directory')
    ap.add_argument('--model', default='model_locked_B_robust.joblib',
                    help='prespecified primary: the robustness-selected model')
    ap.add_argument('--model2', default='model_locked_A_accuracy.joblib',
                    help='prespecified secondary: the accuracy-optimised model')
    ap.add_argument('--cache', default='features_prostate158.parquet')
    ap.add_argument('--out', default='prostate158_results.json')
    a = ap.parse_args()

    cache = Path(a.cache)
    df = pd.read_parquet(cache) if cache.exists() else build_table(a.root)
    if not cache.exists():
        df.to_parquet(cache)

    out = {'n_cases': int(df.case.nunique()), 'n_slices': int(len(df)), 'models': {}}
    for tag, path in (('primary_robust', a.model), ('secondary_accuracy', a.model2)):
        if not Path(path).exists():
            continue
        out['models'][tag] = evaluate_model(df, path)
    json.dump(out, open(a.out, 'w'), indent=2, default=lambda o: None)
    print(json.dumps(out, indent=2, default=lambda o: None))


def evaluate_model(df, model_path):
    from sklearn.metrics import roc_auc_score
    bundle = joblib.load(model_path)
    model, feat_names, thr = bundle['model'], bundle['features'], bundle['threshold']
    X = np.nan_to_num(df[feat_names].values.astype(float))
    df = df.copy()
    df['p'] = model.predict_proba(X)[:, 1]
    out = {'model': Path(model_path).name, 'threshold': float(thr),
           'training': bundle.get('training', ''), 'sha256_of_file':
           hashlib_sha(model_path)}

    # ---- slice level, directly comparable with the earlier slice-level external test
    sl = df[(df.tumour_vox >= TUMOUR_MIN_VOXELS) | (df.has_tumour_case == 0)].copy()
    sl['y'] = (sl.tumour_vox >= TUMOUR_MIN_VOXELS).astype(int)
    if sl.y.nunique() == 2:
        out['slice_level'] = metrics(sl.y.values, sl.p.values, thr)
        out['slice_level']['auc_ci'] = boot_ci(sl.y.values, sl.p.values,
                                               __import__('sklearn.metrics', fromlist=['x']).roc_auc_score)
        out['slice_level']['n'] = int(len(sl))

    # ---- patient level, the clinically meaningful unit
    pat = (df.sort_values('p', ascending=False).groupby('case')
             .agg(p=('p', lambda s: s.head(TOP_K).mean()),
                  y=('has_tumour_case', 'max'), n_slices=('p', 'size')).reset_index())
    if pat.y.nunique() == 2:
        out['patient_level'] = metrics(pat.y.values, pat.p.values, thr)
        out['patient_level']['auc_ci'] = boot_ci(pat.y.values, pat.p.values,
                                                 __import__('sklearn.metrics', fromlist=['x']).roc_auc_score)
        out['patient_level']['n'] = int(len(pat))
    tag = Path(model_path).stem
    pat.to_csv(f'prostate158_patient_predictions_{tag}.csv', index=False)
    df[['case', 'slice', 'tumour_vox', 'has_tumour_case', 'p']].to_csv(
        f'prostate158_slice_predictions_{tag}.csv', index=False)
    return out


if __name__ == '__main__':
    main()

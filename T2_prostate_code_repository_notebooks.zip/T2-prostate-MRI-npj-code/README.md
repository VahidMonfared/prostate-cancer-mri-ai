# T2-only prostate MRI — analysis code

Code for the manuscript *"Data-efficient prostate cancer classification from T2-weighted MRI with
mechanistic auditing and a dual-agent quality-control workflow."*

Everything here is the code that was actually run. The notebooks are the scripts as executed, with
the recorded results committed alongside them, so any reviewer can compare what the code produces
against what the paper reports.

---

## The two headline results, and where they come from

| result | notebook | recorded output |
|---|---|---|
| **Internal pooled out-of-fold ROC-AUC 0.9237** (95% CI 0.8886–0.9526), 243 institutional T2 images | [`02_internal_nested_cv_AUC_0.924.ipynb`](notebooks/02_internal_nested_cv_AUC_0.924.ipynb) | [`results/internal_results.json`](results/internal_results.json) |
| **External patient-level ROC-AUC 0.6432** (95% CI 0.545–0.734), AP 0.7276, 137 Prostate158 patients | [`08_external_Prostate158_AUC_0.643.ipynb`](notebooks/08_external_Prostate158_AUC_0.643.ipynb) | [`results/p158_results_CD.json`](results/p158_results_CD.json) |

Both notebooks are committed **with their execution output visible on GitHub**. Open either one and
the numbers print at the bottom of the last cell. Both were re-run from a clean checkout, from the
committed feature tables only, and reproduced the published values **bit-identically** — see
[`REPRODUCTION.md`](REPRODUCTION.md). Neither needs access to any raw image.

---

## Why the external test is clean

The volume-level model described in the paper was developed partly on 139 Prostate158 patients, so
Prostate158 **cannot** be an external test for that model, and the paper does not claim it is.

The model evaluated in notebook 08 is a **different, image-level model**, trained on the 243
institutional images alone. It never saw Prostate158 during fitting, feature design, hyperparameter
selection or thresholding. Its operating threshold is derived from internal out-of-fold predictions
on institutional data and applied to the external cohort unchanged. The first time a Prostate158
label is read is the final metric call.

**The result is labelled exploratory in the paper and it is labelled exploratory here.** Across the
whole project, several feature representations, domain-alignment methods and aggregation rules were
compared on this cohort before this configuration was reported, so the estimate is optimistic.
Notebooks 10–13 contain every one of those attempts, including the ones that made things worse, so
the number of looks at the test set is auditable rather than hidden.

---

## What the three evidence levels are, and why they are never pooled

| level | cohort | n | figure |
|---|---|---|---|
| internal out-of-fold | institutional | 243 images | AUC 0.883 (CNN ensemble) and 0.924 (this repository's handcrafted model) |
| prespecified held-out | UCLA, patient-disjoint, same public source | 133 patients | 0.717 (0.572–0.853); 0.733 with test-time augmentation |
| independent external | PROMIS, locked precursor | 561 patients | 0.618 (0.566–0.668) |
| exploratory external | Prostate158, this repository's model | 137 patients | 0.643 (0.545–0.734) |

UCLA is a **held-out** cohort, not an independent external one — development and testing drew on the
same public source. PROMIS is the only fully independent cohort. The four rows are not comparable
and are never combined.

---

## The dataset ceiling, and why no higher external number is claimed

Models trained **on Prostate158 itself**, with its own labels, under strict patient-grouped
cross-validation, reach at most **0.7259** across 75 configurations
([`11_dataset_ceiling_analysis.ipynb`](notebooks/11_dataset_ceiling_analysis.ipynb)).

A model trained on 243 images from a different hospital, scanner and country cannot be expected to
beat a model trained on the test data itself. That is why the transferred result is reported at
0.643 rather than pushed higher: the limit is in the data, not in the modelling.

---

## Repository layout

```
notebooks/
  00_cohort_construction.ipynb                     268 files → 243 images, two rules, fixed order
  01_feature_extraction_v2.ipynb                   the 779-feature handcrafted descriptor
  02_internal_nested_cv_AUC_0.924.ipynb         ★  the internal result
  03_robustness_under_simulated_shift.ipynb        robustness tuned on simulated shift only
  04_lock_models_with_sha256.ipynb                 models fingerprinted before external data opened
  05_unsupervised_gland_localiser.ipynb            label-free gland finder, identical in both domains
  06_feature_extraction_v3_gland_aligned.ipynb     gland-aligned and lesion-targeted features
  07_model_selection_internal_only.ipynb           every selection decision, internal labels only
  08_external_Prostate158_AUC_0.643.ipynb       ★  the external result
  09_external_all_locked_models.ipynb              all four transfer results together
  10_external_multislice_export.ipynb              multi-slice export scored lower — and why
  11_dataset_ceiling_analysis.ipynb                what Prostate158 itself can support
  12_domain_adaptation_attempts_all_negative.ipynb every alignment method tried, all reported
  13_dinov2_foundation_features_comparison.ipynb   foundation features lost to handcrafted ones
  14_result_figures.ipynb                          figures for the analyses above
  15_external_from_NIfTI_standalone.ipynb          one script, raw Prostate158 NIfTI in, result out
  manuscript_figures/
    F01_figure1_framework_flowchart.ipynb
    F02_F03_performance_figures.ipynb
    F04_F05_distillation_and_tree.ipynb
    F06_mechanistic_map.ipynb
    F07_dual_agent_application.ipynb
    S_supplementary_figures.ipynb
    EQ_equation_rendering.ipynb

src/          modules the notebooks import: pipeline.py, pipeline3.py, locate.py, final_internal.py
src_scripts/  external_prostate158.py — the standalone command-line external runner
data/         derived feature tables — re-run the modelling without the raw images
results/      the recorded outputs of the runs reported in the paper
models/       the locked models with their SHA-256 fingerprints
```

`src/final_internal.py` holds `build()`, `metrics()` and `boot_ci()`. Every notebook imports those
three functions, so the estimator, the operating-point table and the 2,000-resample bootstrap
interval are defined once and cannot drift between analyses.

---

## Running it

```bash
pip install -r requirements.txt
jupyter lab            # from the repository root
```

Notebooks that need data start with a bootstrap cell that finds the repository root, puts `src/` on
the path and changes into `data/`. Anything a notebook writes therefore lands in `data/`, leaving
the recorded originals in `results/` untouched for comparison.

Notebooks **02** and **08** run from the committed feature tables and need no raw images. The
notebooks that extract features (00, 01, 06) need the image data, which is not redistributed here —
see below.

To run the external test straight from the Prostate158 release as distributed:

```bash
python src_scripts/external_prostate158.py --root /path/to/prostate158
```

(the same code is in notebook 15). It expects `<root>/<case>/t2.nii.gz`,
`t2_anatomy_reader1.nii.gz` and, where available, `t2_tumor_reader1.nii.gz`.

**Do not modify a locked model and re-run the external test.** If the pipeline changes, re-lock
(notebook 04) and say so.

---

## Data

Institutional images are not publicly available: they do not retain patient-level linkage or
complete acquisition metadata and remain subject to institutional privacy and ethics restrictions.
The derived feature tables in `data/` are released so that every modelling step can be reproduced.

Public datasets are available from their providers:

* PI-CAI — https://pi-cai.grand-challenge.org
* Prostate158 — https://github.com/kbressem/prostate158
* Prostate-MRI-US-Biopsy — https://doi.org/10.7937/TCIA.2020.A61IOC1A
* fastMRI Prostate — https://fastmri.med.nyu.edu

---

## Protocol, stated plainly

1. All model selection uses internal cross-validation only.
2. Robustness is tuned on simulated shift applied to internal images, never on external data.
3. Models are fitted on the full internal cohort and locked with SHA-256 **before** any external
   data is opened.
4. Each external cohort is opened once. Both prespecified models are reported, whatever they show.
5. Internal, held-out and independent external estimates are reported separately and never pooled.
6. Negative results are in the repository. Notebooks 10, 12 and 13 are attempts that did not work.

---

## Citation

Monfared V, Gharib MH, Rawassizadeh R. *Data-efficient prostate cancer classification from
T2-weighted MRI with mechanistic auditing and a dual-agent quality-control workflow.*

Earlier preprint: https://arxiv.org/abs/2603.18460
